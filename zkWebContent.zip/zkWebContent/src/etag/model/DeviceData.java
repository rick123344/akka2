package ds.etag.model;

import java.util.Calendar;
import java.util.List;
import java.util.UUID;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;

import util.DSCASSANDRA;

public final class DeviceData {
	public static List getCurrentData(int Limit) {
		Calendar c = Calendar.getInstance();
		long year = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH)+1;
		String prepare = "SELECT * FROM deviceData WHERE slaveid=? and year=? and month=? limit ?;";
		List<Row> rs = DSCASSANDRA.readRecord(prepare, UUID.fromString("c4db0b30-bac6-11e7-9fc8-4ef193934fd2"),year,month,Limit);
		return rs;
	}
}
