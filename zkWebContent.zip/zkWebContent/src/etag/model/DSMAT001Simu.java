package ds.etag.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.zkoss.chart.Point;
import org.zkoss.json.JSONObject;
import org.zkoss.json.parser.JSONParser;

import com.google.gson.Gson;

import ds.etag.domain.DSMAT001;

public final class DSMAT001Simu {
	private static List<DSMAT001> MAT = new ArrayList<DSMAT001>();
	private static Gson gson = new Gson();
	public DSMAT001Simu(){
		parseJsonToMat();
	}
	
	public static List<DSMAT001> getSourceMat(){
		parseJsonToMat();
		return MAT;
	}
	
	private static Map<String,Map<String,Object>> sortMatList(List<DSMAT001> mlist){
		Map<String,Map<String,Object>> sortMat = new HashMap<String,Map<String,Object>>();
		for(DSMAT001 dsmat : mlist){
			Map<String,Object> mat = new HashMap<String,Object>();
			String shelfId = dsmat.getShelfId();
			if(sortMat.containsKey(shelfId)){
				sortMat.get(shelfId).put(dsmat.getId(), dsmat);
			}else{
				sortMat.put(shelfId, new HashMap<String,Object>());
				sortMat.get(shelfId).put(dsmat.getId(), dsmat);
			}
		}
		return sortMat;
	}
	
	public static Point[] matToPoints(List<DSMAT001> mlist){
		List<Point> points = new ArrayList<Point>();
		Map<String, Map<String,Object>> m = sortMatList(mlist);
		for (Map.Entry<String, Map<String,Object>> shelf : m.entrySet()){
			Point shelfPoint = new Point();
			shelfPoint.setId(shelf.getKey());
			shelfPoint.setColor("#42b3f4");
			
			for(Entry<String, Object> mat : shelf.getValue().entrySet()){
				
				DSMAT001 dsmat = (DSMAT001)mat.getValue();
				Point matPoint = new Point();
				shelfPoint.setName(dsmat.getShelfName());
				matPoint.setId(dsmat.getShelfId()+"_"+dsmat.getId());
				matPoint.setName(dsmat.getId());
				matPoint.setParent(shelfPoint.getId());
				matPoint.setValue(1);
				matPoint.setX(dsmat.getPositionX());
				matPoint.setY(dsmat.getPositionY());
				matPoint.setColor("#42b3f4");
				if(dsmat.isOn()){
					matPoint.setColor("#ffeb5b");
					matPoint.setSelected(true);
					matPoint.setVisible(false);
					
				}
				points.add(matPoint);
			}
			points.add(shelfPoint);
		}
		
		return points.toArray(new Point[0]);
	}
	
	private static void parseJsonToMat(){
		MAT.clear();
		JSONObject obj = (JSONObject) new JSONParser().parse(materialJson);
		//outside loop
		for (Object all : obj.keySet()) {
			JSONObject allobj = (JSONObject)obj.get(all);
			//factory
			for(Object factoryId:allobj.keySet()){
				JSONObject factory = (JSONObject)allobj.get(factoryId);
				JSONObject allWorkshop = (JSONObject)factory.get("Workshop");
				//workshop
				for(Object workshopId:allWorkshop.keySet()){
					JSONObject workshop = (JSONObject)allWorkshop.get(workshopId);
					JSONObject allShelf = (JSONObject)workshop.get("Shelfs");
					//shelf
					for(Object shelfId:allShelf.keySet()){
						JSONObject shelf = (JSONObject)allShelf.get(shelfId);
						JSONObject allMat = (JSONObject)shelf.get("materials");
						//material
						for(Object matId:allMat.keySet()){
							JSONObject mat = (JSONObject)allMat.get(matId);
							DSMAT001 dsmat = gson.fromJson(mat.toString(), DSMAT001.class);
							dsmat.setFactory((String)factoryId);
							dsmat.setShelfId((String)shelfId);
							dsmat.setShelfName((String)shelf.get("name"));
							dsmat.setWorkshop((String)workshopId);
							dsmat.setId((String)matId);
							dsmat.setEtagId((String)shelf.get("etagId"));
							MAT.add(dsmat);
						}
					}
				}
				
			}
		}
	}
	
	static final String materialJson = "{"
			+ "\"Factorys\":{"
			+ "		\"FTL\":{"
			+ "			\"Location\":\"china\","
			+ "			\"Workshop\":{"
			+ "				\"A1\":{"
			+ "					\"Shelfs\":{"
    		+ "						\"SH000001\":{"
    		+ "							\"name\":\"貨架A\","
    		+ "							\"etagId\":\"000001D1\","
    		+ "							\"materials\":{"
    		+ "								\"F000035A\":{"
    		+ "									\"amount\":\"5\","
    		+ "									\"unit\":\"piece\","
    		+ "									\"positionX\":\"0\","
    		+ "									\"positionY\":\"0\","
    		+ "									\"isOn\":\"false\""
    		+ "								},"
    		+ "								\"F000006B\":{"
    		+ "									\"amount\":\"3\","
    		+ "									\"unit\":\"piece\","
    		+ "									\"positionX\":\"0\","
    		+ "									\"positionY\":\"1\","
    		+ "									\"isOn\":\"false\""
    		+ "								},"
    		+ "								\"F000700C\":{"
    		+ "									\"amount\":\"20\","
    		+ "									\"unit\":\"piece\","
    		+ "									\"positionX\":\"1\","
    		+ "									\"positionY\":\"0\","
    		+ "									\"isOn\":\"false\""
    		+ "								},"
    		+ "								\"F000000D\":{"
    		+ "									\"amount\":\"6\","
    		+ "									\"unit\":\"piece\","
    		+ "									\"positionX\":\"1\","
    		+ "									\"positionY\":\"1\","
    		+ "									\"isOn\":\"false\""
    		+ "								}"
    		+ "							}"
    		+ "						},"
    		+ "						\"SH000002\":{"
    		+ "							\"name\":\"貨架B\","
    		+ "							\"etagId\":\"000002D6\","
    		+ "							\"materials\":{"
    		+ "								\"S050000A\":{"
    		+ "									\"amount\":\"4\","
    		+ "									\"unit\":\"piece\","
    		+ "									\"positionX\":\"0\","
    		+ "									\"positionY\":\"0\","
    		+ "									\"isOn\":\"false\""
    		+ "								},"
    		+ "								\"S000001B\":{"
    		+ "									\"amount\":\"5\","
    		+ "									\"unit\":\"piece\","
    		+ "									\"positionX\":\"0\","
    		+ "									\"positionY\":\"1\","
    		+ "									\"isOn\":\"false\""
    		+ "								},"
    		+ "								\"S000660D\":{"
    		+ "									\"amount\":\"6\","
    		+ "									\"unit\":\"piece\","
    		+ "									\"positionX\":\"1\","
    		+ "									\"positionY\":\"0\","
    		+ "									\"isOn\":\"false\""
    		+ "								},"
    		+ "								\"S000012D\":{"
    		+ "									\"amount\":\"12\","
    		+ "									\"unit\":\"piece\","
    		+ "									\"positionX\":\"1\","
    		+ "									\"positionY\":\"1\","
    		+ "									\"isOn\":\"false\""
    		+ "								}"
    		+ "							}"
    		+ "						}"
    		+ "					}"
			+ "				}"
			+ "			}"
			+ "		}"
			+ "}"
    	+ "}";
	
}
