package ds.etag.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CommonUse {
	public static JSONObject getJsonFromMap(Map<String, Object> map) throws JSONException {
	    JSONObject jsonData = new JSONObject();
	    for (String key : map.keySet()) {
	        Object value = map.get(key);
	        if (value instanceof Map<?, ?>) {
	            value = getJsonFromMap((Map<String, Object>) value);
	        }
	        jsonData.put(key, value);
	    }
	    return jsonData;
	}
	
	public static Map<String,Object> getMapFromJson(String str) throws JsonParseException, JsonMappingException, IOException{
		HashMap<String,Object> result =
		        new ObjectMapper().readValue(str, HashMap.class);
		return result;
	}
	
	
	
}
