package ds.etag.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

import akka.actor.ActorRef;
import akka.actor.ActorSelection;
import akka.actor.ActorSystem;
import akka.actor.Props;

public final class ActorUtil {
	private static ActorSystem system = null;
	private static Map<String, ActorRef> refsLocal = new HashMap<String, ActorRef>();
	private static Map<String, ActorSelection> refsRemote = new HashMap<String, ActorSelection>();

	public ActorUtil() {
		initActor();
	}

	public static ActorRef getLocalByKey(String key) {
		checkInit();
		return refsLocal.get(key);
	}

	public static ActorSelection getRemoteByKey(String key) {
		checkInit();
		return refsRemote.get(key);
	}

	public static void checkInit() {
		if (system == null) {
			initActor();
		}
	}

	private static void initActor() {

		try {
			Properties prop = loadProperties();
//			System.out.println(prop);
			Config c = ConfigFactory.load();
//			system = ActorSystem.create("ClientSys", c.getConfig("ClientSys"));
//			System.out.println(c.getConfig("ClientSys"));
			system = ActorSystem.create(prop.getProperty("SystemName", "ActorRoot"), c.getConfig("ClientSys"));
			Enumeration<?> e = prop.propertyNames();
			while (e.hasMoreElements()) {
				String key = (String) e.nextElement();
				String value = prop.getProperty(key);
				String[] splstr = key.split("\\.");
				try {
					if (splstr[0].equals("Actors") && splstr[1].equals("remote")) {
						createRemoteActor(splstr[2], value);
					}
					if (splstr[0].equals("Actors") && splstr[1].equals("local")) {
						createLocalActor(splstr[2], value);
					}
				} catch (Exception ee) {
					// ee.printStackTrace();
				}
			}
		} catch (Exception e) {
			// e.printStackTrace();
		}
	}

	public static void createLocalActor(String key, String className) {
		checkInit();
		try {
			if(refsLocal.containsKey(key)){
				system.stop(refsLocal.get(key));
				refsLocal.remove(key);
				//wait for destroy actor
				Thread.sleep(500);
			}
			refsLocal.put(key, system.actorOf(Props.create(Class.forName(className)), key));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void createLocalActorWithParam(String key,String className,Object ...obj){
		checkInit();
		try {
			if(refsLocal.containsKey(key)){
				system.stop(refsLocal.get(key));
				refsLocal.remove(key);
				//wait for destroy actor
				Thread.sleep(500);
			}
			refsLocal.put(key, system.actorOf(Props.create(Class.forName(className),obj), key));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void createRemoteActor(String key, String path) {
		checkInit();
		try{
			if(refsRemote.containsKey(key)){
				refsRemote.remove(key);
			}
			refsRemote.put(key, system.actorSelection(path));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	private static Properties loadProperties() throws IOException {
		Properties prop = new Properties();
		InputStream input = ActorUtil.class.getResourceAsStream("/akka.properties");
		prop.load(input);
		return prop;
	}
	
	protected void finalize(){
		if(system!=null){
			system.terminate();
		}
	}

}
