package ds.etag.akka;

import java.util.Map;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import akka.actor.AbstractActor;
import akka.actor.Props;
import ds.etag.listener.commandListener;
import ds.etag.listener.commandListenerAction;
import ds.etag.util.ActorUtil;
import ds.etag.util.CommonUse;

public class CommandClient extends AbstractActor{
	private static Logger logger = LoggerFactory.getLogger(CommandClient.class);
	private static commandListenerAction cla = new commandListenerAction();
	
	public CommandClient(){
		
	}
	
	public static void addListener(commandListener pec){
		cla.addListener(pec);
	}
	
	public static Props getProps(){
		return Props.create(CommandClient.class);
	}
	
	@Override
	public Receive createReceive() {
		return receiveBuilder()
			.match(Map.class,map->{
//				if(((String)map.get("justSend"))!=null&&((String)map.get("justSend")).equals("Y")){
//					ActorUtil.getRemoteByKey("Command").tell(map,getSelf());
//				}else{
//					String key = (String) map.get("command");
//		            switch (key){
//			            case "onlineDevices":
//			            	Map<String,Object> list = (Map<String, Object>) map.get(key);
//			            	cla.sendResponse("Router Count: "+list.size(),"txt");
//			            	cla.sendResponse(map, "putDeviceArray");
//			            	break;
//			            case "response_Preview":
//			            	cla.sendResponse(map, key);
//			            	break;
//		            }
//				}
	            
	        }).match(String.class,m->{
            	try{
            		JSONObject tmp = new JSONObject(m);
            		String sendType = (String) tmp.get("sendType");
            		switch(sendType){
            			case "justSend":
            				ActorUtil.getRemoteByKey("Command").tell(m,getSelf());
            				break;
            			case "responseFromServer":
            				cla.sendResponse(tmp,(String)tmp.get("command"));
            				break;
            			case "sendFromServer":
            				cla.sendResponse(tmp,(String)tmp.get("command"));
            				break;
            		}
            	}catch(Exception e){
//		            		e.printStackTrace();
            	}
	        }).build();
	}

}