package ds.etag.akka;

import akka.actor.AbstractActor;

public class Sender extends AbstractActor{

	@Override
	public Receive createReceive() {
		// TODO Auto-generated method stub
		return null;
	}

}
