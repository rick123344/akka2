package ds.etag.domain;

import lombok.Data;

@Data
public class DSMAT001 {
	private String id;
	private String shelfId;
	private String shelfName;
	private int amount;
	private String unit;
	private String factory;
	private String workshop;
	private boolean isOn;
	private String etagId;
//	position defined as follow
//	when position is {0,0} ,
//	which positionX first and second is positionY , no position
//	| and so on......
//	| {2,0}	| {2,1}	| {2,2}	|
//	| {1,0}	| {1,1}	| {1,2}	|
//	| {0,0}	| {0,1}	| {0,2}	|
	private int positionX = 0;
	private int positionY = 0;
	
	
	
}
