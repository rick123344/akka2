package ds.etag.listener;

import java.util.ArrayList;
import java.util.List;

public class commandListenerAction {
	private List<commandListener> listeners = new ArrayList<commandListener>();

    public void addListener(commandListener toAdd) {
        listeners.add(toAdd);
    }

    public void sendResponse(Object obj,String method) {
        for (commandListener hl : listeners)
            hl.commandResponse(obj,method);
    }
}
