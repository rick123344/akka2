package ds.etag.listener;

public interface commandListener {
	void commandResponse(Object obj, String method);
}
