package ds.etag.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import org.json.JSONException;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.Desktop;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.HtmlBasedComponent;
import org.zkoss.zk.ui.event.CheckEvent;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.event.SelectEvent;
import org.zkoss.zk.ui.select.SelectorComposer;
import org.zkoss.zk.ui.select.annotation.Listen;
import org.zkoss.zk.ui.select.annotation.Wire;
import org.zkoss.zul.Button;
import org.zkoss.zul.Div;
import org.zkoss.zul.Label;
import org.zkoss.zul.ListModelList;
import org.zkoss.zul.Listbox;
import org.zkoss.zul.Radiogroup;
import org.zkoss.zul.Textbox;
import org.zkoss.zul.Window;

import com.google.gson.Gson;

import akka.actor.ActorRef;
import ds.etag.akka.CommandClient;
import ds.etag.listener.commandListener;
import ds.etag.model.EndDevice;
import ds.etag.model.RespObj;
import ds.etag.model.Router;
import ds.etag.util.ActorUtil;
import ds.etag.util.CommonUse;

public class EtagController extends SelectorComposer<Component> implements commandListener{
	
	@Wire
	private Window windowMaster;
	@Wire
	private Button getOnlineDevice,updateEtag,toastBtn,preview;
	@Wire
	private Textbox txt;
	@Wire
	private Listbox lsonline;
	
	@Wire
	private Textbox deviceId,routerId,battery,sleepTime,lcdIndex,ledType,imageStr;
	@Wire
	private Textbox yellowHighTime,yellowLowTime,greenHighTime,greenLowTime,blueHighTime,blueLowTime,whiteHighTime,whiteLowTime,redHighTime,redLowTime;
	@Wire
	private Radiogroup Yellow,Green,Blue,White,Red;
	@Wire
	private Div toast;
	
	private ListModelList YLightList,GLightList,BLightList,WLightList,RLightList;
	private Gson gson = new Gson();
	private Map<String,Object> deviceListSource = new HashMap<String,Object>();
	private Map<String,Object> commandMap = new HashMap<String,Object>();
	private Desktop desktop = Executions.getCurrent().getDesktop();
	public void doAfterCompose(Component comp) throws Exception{
		super.doAfterCompose(comp);
		
		//set radio
		List<Object> llist = new ArrayList<Object>();
		for(int i = 0; i<=2; i++){
			Map<String,String> lm = new HashMap<String,String>();
			lm.put("value", String.valueOf(i));
			String label = i==0? "OFF":i==1? "ON" : "FLASH";
			lm.put("label", label);
			llist.add(lm);
		}
		YLightList = new ListModelList(llist);
		GLightList = new ListModelList(llist);
		BLightList = new ListModelList(llist);
		WLightList = new ListModelList(llist);
		RLightList = new ListModelList(llist);
		Yellow.setModel(YLightList);
		Green.setModel(GLightList);
		Blue.setModel(BLightList);
		White.setModel(WLightList);
		Red.setModel(RLightList);
		
//		CRUDService = (CRUDService) SpringUtil.getBean("CRUDService");
		
	}
	
	public EtagController(){
		try{
			desktop = Executions.getCurrent().getDesktop();
			desktop.enableServerPush(true);
			CommandClient.addListener(this);
			ActorUtil.getLocalByKey("Command").tell("helloinit", ActorRef.noSender());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	@Listen("onCheck = #Yellow,#Green,#Blue,#White,#Red")
	public void radioClick(CheckEvent event){
//		System.out.println(event.getTarget());
//		System.out.println(event.getSelectedObjects());
		
//		System.out.println(event.getTarget());
//		event.getTarget().getParent().getId();
//		White.setSelectedIndex(0);
		
//		System.out.println(Yellow.getSelectedItem().getLabel());
	}
	
	@Listen("onClick = #getOnlineDevice,#updateEtag,#toastBtn,#preview")
	public void akkaSendTest(Event event){
		commandMap.put("from", this.hashCode());
		commandMap.put("sendType","justSend");
		try{
			switch(event.getTarget().getId()){
				case "getOnlineDevice":
					updateOnlineDevice();
					break;
				case "toastBtn":
					showToast("test message");
					break;
				case "updateEtag":
					String jstr = gson.toJson(deviceListSource.get(routerId.getText()));
					Router router = gson.fromJson(jstr, Router.class);
//					Router router = (Router) deviceListSource.get(routerId.getText());
					EndDevice ed = new EndDevice(router.getDevices().get(deviceId.getText()));
					List<String> preUpdate = compareAndPutValue(ed);
					String edsend = gson.toJson(ed);
					for(String str:preUpdate){
						switch (str){
						case "_sleepTime":
								commandMap.put("command", "_sleepTime");
								commandMap.put("value", edsend);
								sendAkkaTo("Command",commandMap);
							break;
						case "_Image":
								commandMap.put("command", "_Image");
								commandMap.put("value", edsend);
								commandMap.put("buildstr", imageStr.getText().trim());
								sendAkkaTo("Command",commandMap);
							break;
						case "_Light":
								commandMap.put("command", "_Light");
								commandMap.put("value", edsend);
								sendAkkaTo("Command",commandMap);
							break;
						}
					}
					break;
				case "preview":
					commandMap.put("command", "_Preview");
					commandMap.put("buildstr", imageStr.getText().trim());
					sendAkkaTo("Command",commandMap);
					break;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	@Listen("onSelect = #lsonline")
	public void onSelect$ls(SelectEvent event) {
		Set so = event.getSelectedObjects();
//		for(EndDevice e : (Set<EndDevice>)so){
//			System.out.println(e);
//		}
		List<EndDevice> dl = new ArrayList<>(so);
		EndDevice e = dl.get(0);
		putValueByEndDevice(e);
		
	}
	
	public void showToast(String message){
		Div tmp = new Div();
		toast.appendChild(tmp);
		Label label = new Label(message);
		tmp.appendChild(label);
		stopToast(tmp,3000);
		tmp.setSclass("toast toast-animation");
	}
	
	public void stopToast(Div div,long microsecond) {
		Timer timer = new Timer();
		timer.schedule(new TimerTask(){
			@Override
			public void run() {
				putValueOutSideListners(div,"cancelToast");
			}
		},(long)microsecond);
	}
	
	public List<String> compareAndPutValue(EndDevice ed) throws Exception{
		
		List<String> updateList = new ArrayList<String>();
		
		int nst = parseInt(sleepTime.getText());
		if(nst!=ed.getSleepTime()){
			updateList.add("_sleepTime");
		}
		ed.setSleepTime(nst);
		int nli = parseInt(lcdIndex.getText());
		if(nli!=ed.getLcdIndex()){
			updateList.add("_Image");
		}
		ed.setLcdIndex(nli);
		
		int nyht = parseInt(yellowHighTime.getText());
		int nylt = parseInt(yellowLowTime.getText());
		int nys = parseInt(Yellow.getSelectedItem().getValue());
		
		int nght = parseInt(greenHighTime.getText());
		int nglt = parseInt(greenLowTime.getText());
		int ngs = parseInt(Green.getSelectedItem().getValue());
		
		int nbht = parseInt(blueHighTime.getText());
		int nblt = parseInt(blueLowTime.getText());
		int nbs = parseInt(Blue.getSelectedItem().getValue());
		
		int nwht = parseInt(whiteHighTime.getText());
		int nwlt = parseInt(whiteLowTime.getText());
		int nws = parseInt(White.getSelectedItem().getValue());
		
		int nrht = parseInt(redHighTime.getText());
		int nrlt = parseInt(redLowTime.getText());
		int nrs = parseInt(Red.getSelectedItem().getValue());
		
		if(nyht!=ed.getYellow().getHighTime()||nylt!=ed.getYellow().getLowTime()
				||nys!=ed.getYellow().getStatus()||nght!=ed.getGreen().getHighTime()
				||nglt!=ed.getGreen().getLowTime()||ngs!=ed.getGreen().getStatus()
				||nbht!=ed.getBlue().getHighTime()||nblt!=ed.getBlue().getStatus()
				||nbs!=ed.getBlue().getStatus()||nwht!=ed.getWhite().getHighTime()
				||nwlt!=ed.getWhite().getLowTime()||nws!=ed.getWhite().getStatus()
				||nrht!=ed.getRed().getHighTime()||nrlt!=ed.getRed().getLowTime()
				||nrs!=ed.getRed().getStatus()){
			updateList.add("_Light");
		}
		ed.getYellow().setHighTime(nyht);
		ed.getYellow().setLowTime(nylt);
		ed.getYellow().setStatus(nys);
		ed.getGreen().setHighTime(nght);
		ed.getGreen().setLowTime(nglt);
		ed.getGreen().setStatus(ngs);
		ed.getBlue().setHighTime(nbht);
		ed.getBlue().setLowTime(nblt);
		ed.getBlue().setStatus(nbs);
		ed.getWhite().setHighTime(nwht);
		ed.getWhite().setLowTime(nwlt);
		ed.getWhite().setStatus(nws);
		ed.getRed().setHighTime(nrht);
		ed.getRed().setLowTime(nrlt);
		ed.getRed().setStatus(nrs);
		return updateList;
	}
	
	public int parseInt(Object o) throws Exception{
		if(o==null||o.equals("")){
			return 0;
		}
		int i = Integer.valueOf((String) o);
		return i;
	}
	
	public void putValueByEndDevice(EndDevice e){
		deviceId.setText(e.getId());
		routerId.setText(e.getRouteId());
		battery.setText(String.valueOf(e.getBattery()));
		sleepTime.setText(String.valueOf(e.getSleepTime()));
		lcdIndex.setText(String.valueOf(e.getLcdIndex()));
		ledType.setText(e.getLedType());
		yellowHighTime.setText(String.valueOf(e.getYellow().getHighTime()));
		yellowLowTime.setText(String.valueOf(e.getYellow().getLowTime()));
		greenHighTime.setText(String.valueOf(e.getGreen().getHighTime()));
		greenLowTime.setText(String.valueOf(e.getGreen().getLowTime()));
		blueHighTime.setText(String.valueOf(e.getBlue().getHighTime()));
		blueLowTime.setText(String.valueOf(e.getBlue().getLowTime()));
		whiteHighTime.setText(String.valueOf(e.getWhite().getHighTime()));
		whiteLowTime.setText(String.valueOf(e.getWhite().getLowTime()));
		redHighTime.setText(String.valueOf(e.getRed().getHighTime()));
		redLowTime.setText(String.valueOf(e.getRed().getLowTime()));
		
		Yellow.setSelectedIndex(e.getYellow().getStatus());
		Green.setSelectedIndex(e.getGreen().getStatus());
		Blue.setSelectedIndex(e.getBlue().getStatus());
		White.setSelectedIndex(e.getWhite().getStatus());
		Red.setSelectedIndex(e.getRed().getStatus());
	}
	
	//control component outside controller(zk framework)
	public void putValueOutSideListners(Object obj,String method){
		try {
			if (desktop != null && desktop.isAlive()) {
				Executions.activate(desktop);
				switch(method){
					case "txt":
						txt.setValue((String)obj);
						break;
					case "lsonline":
						ListModelList modelRole = new ListModelList((List<Object>)obj, true);
						lsonline.setModel(modelRole);
						break;
					case "cancelToast":
						((HtmlBasedComponent) obj).setSclass("toast");
						toast.removeChild((HtmlBasedComponent)obj);
						break;
					case "showToast":
						showToast((String)obj);
						break;
					case "response_Preview":
						String template = "/ds/common/etag/imagePreview.zul";
						Map<String,Object> m = (HashMap<String,Object>)obj ;
						m.put("buildstr", "test");
						Window window = (Window)Executions.createComponents(template, null, m);
						window.doModal();
						break;
					default:
						break;
				}
				Executions.deactivate(desktop);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	public void putDeviceArray(Map<String,Object> m){
		deviceListSource.clear();
		List<Object> onlines = new ArrayList<Object>();
		try{
			for (Map.Entry<String, Object> r : m.entrySet()){
				String str = gson.toJson(r.getValue());
				Router obj = gson.fromJson(str, Router.class);
				deviceListSource.put(obj.getId(), obj);
				for(Map.Entry<String, EndDevice> ed : obj.getDevices().entrySet()){
			    	onlines.add(ed.getValue());
			    }
			}
			putValueOutSideListners(onlines,"lsonline");
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void updateOnlineDevice(){
		try{
			Map<String,Object> cmap = new HashMap<String,Object>();
			cmap.put("command", "onlineDevicesSearch");
			cmap.put("sendType", "justSend");
			cmap.put("from",this.hashCode());
			sendAkkaTo("Command",cmap);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void sendAkkaTo(String dist,Map<String,Object> map){
		try {
			ActorUtil.getLocalByKey(dist).tell(CommonUse.getJsonFromMap(map).toString(), ActorRef.noSender());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public void commandResponse(Object obj, String method) {
		Map<String,Object> tmp;
		try{
			switch(method){
				case "response_Preview":
					tmp = CommonUse.getMapFromJson(obj.toString());
					if(tmp.get("from").equals(this.hashCode())){
						putValueOutSideListners(tmp,method);
					}
					break;
				case "updateOnlineDevice":
					updateOnlineDevice();
					break;
				case "onlineDevices":
					tmp = CommonUse.getMapFromJson(obj.toString());
					Map<String,Object> list = (Map<String, Object>) tmp.get(method);
					putValueOutSideListners("Router Count: "+list.size(),"txt");
					if(tmp.get("from").equals(this.hashCode())){
						putDeviceArray(list);
//						putValueOutSideListners(tmp.get("from")+" : update Device Success","showToast");
					}
					break;
				case "showRouterResponse":
					tmp = CommonUse.getMapFromJson(obj.toString());
					RespObj resp = gson.fromJson((String) tmp.get("RespObj"), RespObj.class);
					updateOnlineDevice();
					putValueOutSideListners(resp.getDeviceTmp().getId()+": "+resp.getBaseType(),"showToast");
					break;
				default:
					putValueOutSideListners(obj,method);
					break;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
}
