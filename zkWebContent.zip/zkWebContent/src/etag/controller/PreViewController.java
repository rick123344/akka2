package ds.etag.controller;

import java.awt.image.BufferedImage;
import java.util.ArrayList;

import org.zkoss.bind.annotation.AfterCompose;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.Execution;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.select.SelectorComposer;
import org.zkoss.zk.ui.select.annotation.Listen;
import org.zkoss.zk.ui.select.annotation.Wire;
import org.zkoss.zul.Button;
import org.zkoss.zul.Image;
import org.zkoss.zul.Window;

import ds.etag.util.Common;

public class PreViewController extends SelectorComposer<Component>{

	@Wire
	private Window previewWin;
	@Wire
	private Button closeBtn;
	@Wire
	private Image preview;
	
	private String buildstr;
	private BufferedImage bi;
	final Execution execution = Executions.getCurrent();
	@AfterCompose
	public void doAfterCompose(Component comp) throws Exception{
		super.doAfterCompose(comp);
		try{
			buildstr = (String) execution.getArg().get("buildstr");
			ArrayList<Integer> sa = (ArrayList<Integer>) execution.getArg().get("image");
			byte[] ba = new byte[sa.size()];
			for(int i= 0; i<sa.size();i++){
				ba[i] = Byte.valueOf(String.valueOf(sa.get(i)));
			}
			bi = Common.bytesToImage(ba);
			
			preview.setContent(bi);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	@Listen("onClick = #closeBtn")
	public void close(){
		previewWin.detach();
	}
	
}
