package ds.etag.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import org.json.JSONException;
import org.json.JSONObject;
import org.zkoss.chart.Charts;
import org.zkoss.chart.ChartsEvent;
import org.zkoss.chart.ColorAxis;
import org.zkoss.chart.Legend;
import org.zkoss.chart.Level;
import org.zkoss.chart.Point;
import org.zkoss.chart.Series;
import org.zkoss.chart.YAxis;
import org.zkoss.chart.model.DefaultXYZModel;
import org.zkoss.chart.model.XYZModel;
import org.zkoss.chart.plotOptions.DataLabels;
import org.zkoss.chart.plotOptions.TreemapPlotOptions;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.Desktop;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.HtmlBasedComponent;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.select.SelectorComposer;
import org.zkoss.zk.ui.select.annotation.Listen;
import org.zkoss.zk.ui.select.annotation.Wire;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zkplus.spring.SpringUtil;
import org.zkoss.zul.Button;
import org.zkoss.zul.Div;
import org.zkoss.zul.Label;
import org.zkoss.zul.ListModelList;
import org.zkoss.zul.Listbox;

import com.google.gson.Gson;

import akka.actor.ActorRef;
import ds.common.services.CRUDService;
import ds.etag.akka.CommandClient;
import ds.etag.domain.DSMAT001;
import ds.etag.listener.commandListener;
import ds.etag.model.DSMAT001Simu;
import ds.etag.model.RespObj;
import ds.etag.util.ActorUtil;
import ds.etag.util.CommonUse;

public class StoredDemo extends SelectorComposer<Component> implements commandListener{
	@WireVariable
	private CRUDService CRUDService;
	@Wire
    Charts chart,chart2;
	@Wire
	Button testBtn,cancelBtn,getQueue;
	@Wire
	Div toast;
	@Wire
	Listbox queueList;
	Series series;
	private static Gson gson = new Gson();
	public List<DSMAT001> mats = DSMAT001Simu.getSourceMat();
	private Desktop desktop = Executions.getCurrent().getDesktop();
	
	public StoredDemo(){
		try{
			desktop = Executions.getCurrent().getDesktop();
			desktop.enableServerPush(true);
			CommandClient.addListener(this);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void doAfterCompose(Component comp) throws Exception{
		super.doAfterCompose(comp);
		CRUDService = (CRUDService) SpringUtil.getBean("CRUDService");
		
		series = chart.getSeries();
		//hide the tooltip
		chart.getTooltip().setEnabled(false);
		DataLabels labels = series.getDataLabels();
		labels.setEnabled(false);
		
        series.setType("treemap");
        TreemapPlotOptions treemapPlotOptions = new TreemapPlotOptions();
        treemapPlotOptions.setLayoutAlgorithm("squarified");
        treemapPlotOptions.setAllowDrillToNode(true);
        DataLabels dataLabels = new DataLabels();
        dataLabels.setEnabled(false);
        treemapPlotOptions.setDataLabels(dataLabels);
        treemapPlotOptions.setLevelIsConstant(false);
        Level level = new Level();
        //show directly
        DataLabels dataLabels2 = new DataLabels();
        
        dataLabels2.setEnabled(true);
        level.setDataLabels(dataLabels2);
        level.setLevel(1);
        level.setBorderWidth(3);
        treemapPlotOptions.setLevels(Arrays.asList(level));
        series.setPlotOptions(treemapPlotOptions);
        series.setData(DSMAT001Simu.matToPoints(mats));
        test();
	}
	
	@Listen("onClick=#testBtn,#cancelBtn,#getQueue")
	public void btnClick(Event event){
		switch(event.getTarget().getId()){
			case "testBtn":
//				List<Row> rl = DeviceData.getCurrentData(1);
//				for(Row r:rl) {
//					showToast(((UUID)r.getObject("slaveid")).toString());
//					String data = r.getString("data");
////					showToast(data);
//					try {
//						JSONObject obj = new JSONObject(data);
//						showToast(obj.getString("19"));
//					} catch (JSONException e) {
//						e.printStackTrace();
//					}
//				}
				changeTreeMapList();
				break;
			case "cancelBtn":
				cancelTreeMapList();
				break;
			case "getQueue":
				getQueueList();
				break;
		}
	}
	
	@Listen("onDelete = #queueList")
	public void delQueueList(Event event) {
		System.out.println(event.getData());
		removeQueueList((Map<String,Object>)event.getData());
	}
	
	@Listen("onPlotClick = #chart")
    public void shiftPoint(ChartsEvent event) {
        // retrieve the point object.
//        Point point = event.getPoint();
//        System.out.println(point);
    }
	
	public void changeTreeMapList(){
		mats.get(0).setOn(true);
		mats.get(4).setOn(true);
		sendAkkaUpdateDevice(0,"1");
		sendAkkaUpdateDevice(4,"1");
		sendAkkaUpdateDevice(0,"9");
		sendAkkaUpdateDevice(4,"9");
//		System.out.println(DSMAT001Simu.matToPoints(mats));
		series.setData(DSMAT001Simu.matToPoints(mats));
	}
	
	public void cancelTreeMapList(){
		mats.get(0).setOn(false);
		mats.get(4).setOn(false);
		sendAkkaUpdateDevice(0,"0");
		sendAkkaUpdateDevice(4,"0");
		sendAkkaUpdateDevice(0,"10");
		sendAkkaUpdateDevice(4,"10");
		series.setData(DSMAT001Simu.matToPoints(mats));
	}
	
	public void getQueueList() {
		Map<String,Object> cmap = new HashMap<String,Object>();
		cmap.put("command", "_getQueueList");
		cmap.put("sendType", "justSend");
		cmap.put("from",this.hashCode());
		try {
			ActorUtil.getLocalByKey("Command").tell(CommonUse.getJsonFromMap(cmap).toString(), ActorRef.noSender());
		}catch(Exception e) {
			
		}
	}
	
	public void removeQueueList(Map<String,Object> obj) {
		Map<String,Object> cmap = new HashMap<String,Object>();
		cmap.put("command", "_removeQueueList");
		cmap.put("sendType", "justSend");
		cmap.put("removeObj", obj);
		cmap.put("from",this.hashCode());
		try {
			ActorUtil.getLocalByKey("Command").tell(CommonUse.getJsonFromMap(cmap).toString(), ActorRef.noSender());
		}catch(Exception e) {
			
		}
	}
	
	@Override
	public void commandResponse(Object obj, String method) {
		Map<String,Object> tmp;
		try{
			switch(method){
				case "showRouterResponse":
					tmp = CommonUse.getMapFromJson(obj.toString());
					RespObj resp = gson.fromJson((String) tmp.get("RespObj"), RespObj.class);
					putValueOutSideListners(resp.getDeviceTmp().getId()+": "+resp.getBaseType(),"showToast");
					break;
				case "showDeviceTimeout":
					tmp = CommonUse.getMapFromJson(obj.toString());
					putValueOutSideListners(tmp.get("deviceId")+" Timeout, Retring...","showToast");
					break;
				case "Error":
					putValueOutSideListners(((JSONObject)obj).getString("Error"),"showToast");
					break;
				case "response_Queue":
					putValueOutSideListners(obj,method);
					break;
				case "response_rmQueue":
					putValueOutSideListners(obj,method);
					break;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private static final String[][] Code = {{"A","B"},{"C","D"}};
	public void sendAkkaUpdateDevice(int index,String type){
		Map<String,Object> commandMap = new HashMap<String,Object>();
		commandMap.put("from", this.hashCode());
		commandMap.put("sendType","justSend");
		commandMap.put("command", "_updateSingleId");
		commandMap.put("whereToUpdate", type);
		commandMap.put("value", mats.get(index).getEtagId());
		String code = Code[mats.get(index).getPositionX()][mats.get(index).getPositionY()];
		String upLine = mats.get(index).getFactory()+mats.get(index).getWorkshop();
		String downLine = mats.get(index).getId();
		String barcode = mats.get(index).getId();
		commandMap.put("imageStr", code+","+upLine+","+downLine+","+barcode);
		try {
			ActorUtil.getLocalByKey("Command").tell(CommonUse.getJsonFromMap(commandMap).toString(), ActorRef.noSender());
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	
	
	public void showToast(String message){
		Div tmp = new Div();
		toast.appendChild(tmp);
		Label label = new Label(message);
		tmp.appendChild(label);
		stopToast(tmp,3000);
		tmp.setSclass("toast toast-animation");
	}
	
	public void stopToast(Div div,long microsecond) {
		Timer timer = new Timer();
		timer.schedule(new TimerTask(){
			@Override
			public void run() {
				putValueOutSideListners(div,"cancelToast");
			}
		},(long)microsecond);
	}
	
	public void putValueOutSideListners(Object obj,String method){
		try {
			if (desktop != null && desktop.isAlive()) {
				Executions.activate(desktop);
				if(!method.equals("response_Queue")) {
					getQueueList();
				}
				switch(method){
					case "showToast":
						showToast((String)obj);
						break;
					case "cancelToast":
						((HtmlBasedComponent) obj).setSclass("toast");
						toast.removeChild((HtmlBasedComponent)obj);
						break;
					case "response_Queue":
						Map<String,Object> tmp = CommonUse.getMapFromJson(obj.toString());
						if(tmp.get("from").equals(this.hashCode())){
							List<Map<String,Object>> queue = (List<Map<String,Object>>)tmp.get("queueList");
							ListModelList modelRole = new ListModelList(queue, true);
							queueList.setModel(modelRole);
						}
						break;
					case "response_rmQueue":
//						getQueueList();
						break;
					default:
						break;
				}
				Executions.deactivate(desktop);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	
	//test
	public void test(){
		YAxis yaxis = chart2.getYAxis();
        ColorAxis cAxis = chart2.getColorAxis();
        Legend legend = chart2.getLegend();
        Series series = chart2.getSeries();
        DataLabels labels = series.getDataLabels();
        chart2.getTooltip().setEnabled(false);
        chart2.setModel(model);
        
        chart2.setMarginTop(40);
        chart2.setMarginBottom(80);
        chart2.setPlotBorderWidth(1);
        chart2.getXAxis().setCategories(new String[] {"Alexander", "Marie", "Maximilian", "Sophia", "Lukas", "Maria", "Leon", "Anna", "Tim", "Laura"});
        yaxis.setCategories(new String[] {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"});
        yaxis.setTitle("");
        cAxis.setMin(new Integer(0));
        cAxis.setMinColor("#FFFFFF");
        cAxis.setMaxColor(chart2.getColors().get(0));
        legend.setAlign("right");
        legend.setLayout("vertical");
        legend.setMargin(new Integer(0));
        legend.setVerticalAlign("top");
        legend.setY(new Integer(25));
        legend.setSymbolHeight(new Integer(280));
        series.setBorderWidth(new Integer(1));
        labels.setEnabled(true);
        labels.setColor("black");
	}
	
	private static XYZModel model;
    static {
        final Integer[][] data = { { 0, 0, 10 }, { 0, 1, 19 }, { 0, 2, 8 },
                { 0, 3, 24 }, { 0, 4, 67 }, { 1, 0, 92 }, { 1, 1, 58 },
                { 1, 2, 78 }, { 2, 0, 35 },
                { 2, 1, 15 }, { 2, 2, 123 }, { 2, 3, 64 }, { 2, 4, 52 },
                { 3, 0, 72 }, { 3, 1, 132 }, { 3, 2, 114 }, { 3, 3, 19 },
                { 3, 4, 16 }, { 4, 0, 38 },  { 4, 2, 8 },
                { 4, 3, 117 }, { 4, 4, 115 }, { 5, 0, 88 }, { 5, 1, 32 },
                { 5, 2, 12 },  { 6, 0, 13 },
                { 6, 1, 44 }, { 6, 2, 88 }, { 6, 3, 98 }, { 6, 4, 96 },
                { 7, 0, 31 }, { 7, 1, 1 }, { 7, 2, 82 }, { 7, 3, 32 },
                { 7, 4, 30 }, { 8, 0, 85 }, { 8, 1, 97 } };
        model = new DefaultXYZModel();
        for (Integer[] value : data) {
            model.addValue("Sales per employee", value[0], value[1], value[2]);
        }
    }
	
}
