package ds.eserver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ds.eserver.controller.etagController;
import ds.eserver.util.ActorUtil;
import ds.etag.thread.RouterListenerThread;

public class Startup {
	private static Logger logger = LoggerFactory.getLogger(Startup.class);
	public Startup(){
		
		RouterListenerThread.etagThreadStart();
		ActorUtil.initActor();
		new etagController();
		
	}
	
}
