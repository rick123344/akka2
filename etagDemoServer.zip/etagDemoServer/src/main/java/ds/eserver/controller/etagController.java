package ds.eserver.controller;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;
import java.util.Set;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import akka.actor.ActorRef;
import ds.eserver.util.ActorUtil;
import ds.eserver.util.ServerCommon;
import ds.etag.listener.etagListener;
import ds.etag.listener.timeoutListener;
import ds.etag.model.EndDevice;
import ds.etag.model.RespObj;
import ds.etag.model.Router;
import ds.etag.repository.RoutersCollect;
import ds.etag.thread.RouterListenerThread;
import ds.etag.util.ActionType;
import ds.etag.util.Common;

public final class etagController extends Thread implements etagListener {

	private static Logger logger = LoggerFactory.getLogger(etagController.class);
	private static Map<String,Object> processingDevice = new HashMap<String,Object>();
//	private static Map<String,Map<String,Object>> queueDevice = new HashMap<String,Map<String,Object>>();
	private static List<Map<String,Object>> queueDevice = new ArrayList<>();
	public etagController(){
		RouterListenerThread.addEtagListener(this);
		this.start();
	}
	
	public void run(){
		while(true){
			try{
//				Thread.sleep(1000);
				Thread.sleep(10);
				checkAndAddQueueList();
				for(Entry<String,Object> m: processingDevice.entrySet()){
					try{
						Router rt = RoutersCollect.getRouters().get(m.getKey());
						if(rt!=null){
							//set timeout callback
							rt.setDeviceTimeoutAction(new timeoutListener(){
								private Router rt;
								@Override
								public void timeoutAction() {
									System.out.println(rt.getId()+" timeout...");
									sendToClient(rt.getId());
								}
								private timeoutListener init(Router rt){
									this.rt = rt;
									return this;
								}
							}.init(rt));
							Map<String,Object> tmpm = (Map<String,Object>)m.getValue();
							for(Entry<String,Object> obj: tmpm.entrySet()){
								Map<String,Object> updateObj = (Map<String,Object>)obj.getValue();
								EndDevice ed = (EndDevice) updateObj.get("endDevice");
								String type = (String)updateObj.get("type");
								EndDevice realed = rt.getDevices().get(ed.getId());
								if(realed!=null){
									doUpdateDevice(ed,rt,type);
									break;
								}
							}
						}
					}catch(Exception e){
//						e.printStackTrace();
					}
				}
			}catch(Exception e){
//				e.printStackTrace();
			}
		}
	}
	
	public void doUpdateDevice(EndDevice ed, Router rt, String type) throws IOException, InterruptedException{
		if(!rt.isBusy()){
			switch(type){
				case "_Light":
					System.out.println("update "+ed.getId()+" light;");
					ActionType.sendToUpdateLedStatus(ed, rt);
					break;
				case "_Image":
					System.out.println("update "+ed.getId()+" Image;");
					EndDevice realed = RoutersCollect.getDeviceByDeviceId(ed.getId());
					realed.setData(ed.getData());
//					ed.setTimeout(3000);
					ActionType.sendToUpdateImage(realed, rt);
					break;
				case "_sleepTime":
					ActionType.sendToUpdateSleepTime(ed, rt);
					break;
			}
		}
	}
	
	public static void checkAndAddQueueList(){
		for(int i = 0; i<queueDevice.size();i++){
			Map<String,Object> m = queueDevice.get(i);
			String deviceId = (String)m.get("deviceId");
			Router r = RoutersCollect.getRouterByDeviceId(deviceId);
			//not online , ignore it
			if(r==null){continue;}
			String routerId = r.getId();
			Map<String,Object> rm = (Map<String,Object>)processingDevice.get(routerId);
			
			if(rm!=null){
				if(m.get("endDevice")==null){
					m.put("endDevice", prepareUpdateDevice(m));
				}
				Map<String, Object> ks = (Map<String,Object>)rm.get(deviceId);
				if(ks!=null) {
					if(ks.containsValue(m.get("key"))) {
						rm.put(deviceId, m);
						queueDevice.remove(i);
					}
				}else {
					rm.put(deviceId, m);
					queueDevice.remove(i);
				}
			}else{
				Map<String,Object> obj = new HashMap<String,Object>();
				if(m.get("endDevice")==null){
					m.put("endDevice", prepareUpdateDevice(m));
				}
				obj.put(deviceId, m);
				processingDevice.put(routerId, obj);
				queueDevice.remove(i);
			}
		}
	}
	
	public static EndDevice prepareUpdateDevice(Map<String,Object> pre){
		String whereToUpdate = (String)pre.get("whereToUpdate");
		String deviceId = (String)pre.get("deviceId");
		Router r = RoutersCollect.getRouterByDeviceId(deviceId);
//		EndDevice ed = new EndDevice(r.getDevices().get(deviceId));
		EndDevice ed = r.getDevices().get(deviceId);
		switch(whereToUpdate){
			case "0":
				pre.put("type", "_Light");
				ed.getYellow().setStatus(0);
				ed.getGreen().setStatus(0);
				ed.getBlue().setStatus(0);
				ed.getRed().setStatus(0);
				ed.getWhite().setStatus(0);
				break;
			case "1":
				pre.put("type", "_Light");
				ed.getYellow().setStatus(1);
				break;
			case "9":
				pre.put("type", "_Image");
				BufferedImage bis = ServerCommon.createImageByStr((String)pre.get("imageStr"));
				try {
					ed.setData(Common.imageToStringArray(bis));
				} catch (IOException e) {
					e.printStackTrace();
				}
				break;
			case "10":
				pre.put("type", "_Image");
				try {
					ed.setData(Common.imageToStringArray(Common.createEmptyImage()));
				} catch (IOException e) {
					e.printStackTrace();
				}
				break;
		}
		return ed;
	}
	
	public static void addToQueue(Map<String,Object> mm){
		Map<String,Object> m = new HashMap<String,Object>(mm);
		String key = (String)m.get("deviceId")+"_"+(String)m.get("whereToUpdate");
		m.put("key", key);
//		queueDevice.put(key, m);
		
		queueDevice.add(m);
	}
	
	public static List getQueue() {
		return queueDevice;
	}
	
	public static void removeQueue(Map<String,Object> obj) {
		queueDevice.remove(obj);
	}
	
	public static void removeProcessList(String ide,String idr){
		Map<String,Object> m = (Map<String,Object>)processingDevice.get(idr);
		m.remove(ide);
	}
	
	public static void removeProcessList(RespObj obj){
		try{
			Map<String,Object> m = (Map<String,Object>)processingDevice.get(obj.getRouterId());
			m.remove(obj.getDeviceTmp().getId());
		}catch(Exception e){
			
		}
	}
	@Override
	public void etagResponse(RespObj obj) {
		switch(obj.getBaseType()){
			case "LEDSuccess":
				removeProcessList(obj);
				sendToClient(obj);
				break;
			case "SleepTimeSuccess":
				removeProcessList(obj);
				sendToClient(obj);
				break;
			case "SleepTimeFail":
				sendToClient(obj);
				break;
			case "LCDSuccess":
				System.out.println("image success............");
				long startTime = System.nanoTime();
				removeProcessList(obj);
				sendToClient(obj);
				System.out.println("finish image action... "+ TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-startTime));
				break;
			case "LEDFail":
				sendToClient(obj);
				break;
			case "AskImageUpdate":
				sendToClient(obj);
				break;
			case "LCDFail":
				sendToClient(obj);
				break;
			case "LCDCommand":
				
//				System.out.println(obj.getDeviceTmp().getAddress());
//				System.out.println(obj.getBaseType()+" : "+RoutersCollect.getRouters().get(obj.getRouterId()).isBusy());
				break;
		}
	}
	
	private void sendToClient(RespObj obj){
		if(!obj.getBaseType().equals("AskImageUpdate")){
			RoutersCollect.setBusyByRouterId(obj.getRouterId(), false);
		}
		JSONObject json = new JSONObject();
		json.put("sendType","sendFromServer");
		json.put("command", "showRouterResponse");
		json.put("RespObj", new JSONObject(obj).toString());
		ActorUtil.getRemoteByKey("Command").tell(json.toString(), ActorRef.noSender());
	}
	
	private void sendToClient(String id){
		JSONObject json = new JSONObject();
		json.put("sendType","sendFromServer");
		json.put("command", "showDeviceTimeout");
		json.put("deviceId", id);
		ActorUtil.getRemoteByKey("Command").tell(json.toString(), ActorRef.noSender());
	}
	
	
}
