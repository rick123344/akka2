package ds.eserver.akka;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;

import akka.actor.AbstractActor;
import akka.actor.Props;
import ds.eserver.controller.etagController;
import ds.eserver.util.ServerCommon;
import ds.etag.model.EndDevice;
import ds.etag.model.Router;
import ds.etag.repository.RoutersCollect;
import ds.etag.util.ActionType;
import ds.etag.util.Common;

public class Command extends AbstractActor{
	private static Logger logger = LoggerFactory.getLogger(Command.class);
	private static ObjectMapper mapper = new ObjectMapper();
	private static Map<String,Object> prepare= new HashMap<String,Object>(); 
	public static Props getProps(){
		return Props.create(Command.class);
	}
	
	private boolean letterWithSender(){
		//check the letter has sender
		if(getSender()!=getContext().system().deadLetters()){
			return true;
		}else{
			return false;
		}
	}
	
	@Override
	public Receive createReceive() {
		
		return receiveBuilder()
			.match(String.class,s->{
	            if(letterWithSender()){
		            try{
		            	JSONObject obj = new JSONObject(s);
	            		String command = (String)obj.get("command");
	            		obj.put("sendType","responseFromServer");
	            		switch(command){
		            		case "onlineDevicesSearch":
			            		obj.put("command", "onlineDevices");
			            		obj.put("onlineDevices", RoutersCollect.getRouters());
			            		getSender().tell(obj.toString(), getSelf());
		            			break;
		            		case "_sleepTime":
		            			update_sleepTime(obj);
		            			break;
		            		case "_Image":
		            			update_Image(obj);
		            			break;
		            		case "_Light":
		            			update_Light(obj);
		            			break;
		            		case "_Preview":
		            			obj.put("justSend", "toController");
		            			obj.put("command", "response_Preview");
		            			BufferedImage bi = ServerCommon.createImageByStr((String)obj.get("buildstr"));
		            			obj.put("image", Common.getImageOrgBytes(bi));
		            			getSender().tell(obj.toString(), getSelf());
		            			break;
		            		case "_getQueueList":
		            			obj.put("justSend","toController");
		            			obj.put("command", "response_Queue");
		            			obj.put("queueList", etagController.getQueue());
		            			getSender().tell(obj.toString(), getSelf());
		            			break;
		            		case "_removeQueueList":
		            			obj.put("justSend","toController");
		            			obj.put("command", "response_rmQueue");
		            			etagController.removeQueue(ServerCommon.getMapFromJson(obj.get("removeObj").toString()));
		            			obj.put("status", true);
		            			getSender().tell(obj.toString(), getSelf());
		            			break;
		            		case "_updateSingleId":
		            			updateSingeIdWithType(obj);
		            			break;
	            		}
	            	}catch(Exception e){
//	            		e.printStackTrace();
	            		System.out.println(e.toString());
	            		JSONObject obj = new JSONObject();
	            		obj.put("Error", "Error: "+e.toString());
	            		obj.put("sendType","responseFromServer");
	            		obj.put("command", "Error");
	            		obj.put("source", s);
	            		getSender().tell(obj.toString(), getSelf());
	            	}
	            }
	        })
			.match(Map.class, map->{
				
			}).build();
	}
	
	private void update_sleepTime(JSONObject obj) throws IOException, InterruptedException{
		EndDevice ed = mapper.readValue((String)obj.get("value"), EndDevice.class);
		Router rt = RoutersCollect.getRouterByDeviceId(ed.getId());
		if(rt!=null){
			if(rt.getDevices().get(ed.getId())!=null){
				rt.getDevices().put(ed.getId(),ed);
				ActionType.sendToUpdateSleepTime(ed, rt);
			}
		}
	}
	private void update_Image(JSONObject obj) throws IOException, InterruptedException{
		BufferedImage bis = ServerCommon.createImageByStr((String)obj.get("buildstr"));
		EndDevice ed = mapper.readValue((String)obj.get("value"), EndDevice.class);
		Router rt = RoutersCollect.getRouterByDeviceId(ed.getId());
		if(rt!=null){
			
			EndDevice edreal = rt.getDevices().get(ed.getId());
			if(edreal!=null){
				edreal.setData(Common.imageToStringArray(bis));
				edreal.setLcdIndex(ed.getLcdIndex());
				edreal.setUpdateImageType(1);
				ActionType.sendToUpdateImage(edreal, rt,false);
			}
		}
	}
	private void update_Light(JSONObject obj) throws IOException, InterruptedException{
		EndDevice ed = mapper.readValue((String)obj.get("value"), EndDevice.class);
		Router rt = RoutersCollect.getRouterByDeviceId(ed.getId());
		if(rt!=null){
			if(rt.getDevices().get(ed.getId())!=null){
				rt.getDevices().put(ed.getId(),ed);
				prepare.put("endDevice", new EndDevice(ed));
				prepare.put("deviceId", ed.getId());
				prepare.put("type", "_Light");
				etagController.addToQueue(prepare);
//				ActionType.sendToUpdateLedStatus(ed, rt);
			}
		}else{
			logger.info("router is null, device not online...");
		}
	}
	
	private void updateSingeIdWithType(JSONObject obj) throws IOException, InterruptedException{
		String id = obj.getString("value");
		String whereToUpdate = obj.getString("whereToUpdate");
		String imageStr = obj.getString("imageStr");
		prepare.put("deviceId", id);
		prepare.put("whereToUpdate", whereToUpdate);
		prepare.put("imageStr", imageStr);
		etagController.addToQueue(prepare);
	}
	
	private void removeQueue() {
		
	}
	
}
