package ds.eserver.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

import akka.actor.ActorRef;
import akka.actor.ActorSelection;
import akka.actor.ActorSystem;
import akka.actor.Props;

public final class ActorUtil {
	private static ActorSystem system;
	private static Map<String,ActorRef> refsLocal = new HashMap<String,ActorRef>();
	private static Map<String,ActorSelection> refsRemote = new HashMap<String,ActorSelection>();
	public ActorUtil(){
		initActor();
	}
	
	public static ActorRef getLocalByKey(String key){
		return refsLocal.get(key);
	}
	
	public static ActorSelection getRemoteByKey(String key){
		return refsRemote.get(key);
	}
	
	public static void initActor(){
		
		try{
			Properties prop = loadProperties();
			Config c = ConfigFactory.load();
			system = ActorSystem.create(prop.getProperty("SystemName","ActorRoot"), c.getConfig("ServerSys"));
			Enumeration<?> e = prop.propertyNames();
			while (e.hasMoreElements()) {
				String key = (String) e.nextElement();
				String value = prop.getProperty(key);
				String[] splstr = key.split("\\.");
				try{
					if(splstr[0].equals("Actors")&&splstr[1].equals("remote")){
						createRemoteActor(splstr[2],value);
					}
					if(splstr[0].equals("Actors")&&splstr[1].equals("local")){
						createLocalActor(splstr[2],value);
					}
				}catch(Exception ee){
//					ee.printStackTrace();
				}
			}
		}catch(Exception e){
//			e.printStackTrace();
		}
	}
	
	private static void createLocalActor(String key,String className){
		try {
			refsLocal.put(key, system.actorOf(Props.create(Class.forName(className)),key));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	private static void createRemoteActor(String key,String path){
		refsRemote.put(key, system.actorSelection(path));
	}
	private static Properties loadProperties() throws IOException{
		Properties prop = new Properties();
		InputStream input = ActorUtil.class.getResourceAsStream("/akka.properties");
		prop.load(input);
		return prop;
	}
	
}
