package ds.eserver.util;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.krysalis.barcode4j.impl.AbstractBarcodeBean;
import org.krysalis.barcode4j.impl.code128.Code128Bean;
import org.krysalis.barcode4j.impl.code39.Code39Bean;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;
import org.krysalis.barcode4j.tools.UnitConv;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public final class ServerCommon {
	private final static Color WhiteRGB = new Color(255, 255, 255);
	private final static int white = WhiteRGB.getRGB();
	private final static Color BlackRGB = new Color(0, 0, 0);
	private final static int black = BlackRGB.getRGB();
	
	public static BufferedImage createImageByStr(String buildstr){
		String[] ss = new String[4];
		try{
			String[] temp = buildstr.split("\\,",-1);
			for(int i = 0; i<ss.length;i++) {
				if(i>=temp.length) {
					ss[i] = "";
					continue;
				}
				ss[i] = temp[i].trim();
			}
		}catch(Exception e) {
//			e.printStackTrace();
			for(int i = 0; i<4;i++) {
				ss[i] = "";
			}
		}
		int index = 0;
		try{
			ss[3] = ss[3].equals("")? "00000000":ss[3];
			index = Integer.valueOf(ss[0]);
		}catch(Exception e){
			
		}
		return createImageWithBarCode(index,ss[1],ss[2],ss[3]);
	}
	
	public static BufferedImage createImageWithBarCode(int index,String cateStr1,String cateStr2,String barStr) {
		List englist = Arrays.asList("A","B","C","D","E","F","G","H","I","J");	
//		Color WhiteRGB = new Color(255, 255, 255);
//		int white = WhiteRGB.getRGB();
//		Color BlackRGB = new Color(0, 0, 0);
//		int black = BlackRGB.getRGB();
		int fontSize = 12;
		BufferedImage bimg = new BufferedImage(296,128,BufferedImage.TYPE_INT_RGB);
		Graphics2D g = bimg.createGraphics();
        g.setColor(WhiteRGB); 
        g.fillRect(0, 0,296,128);
        
        g.setColor(BlackRGB);
        g.drawRect(1,1,293,125);
        Font font = new Font("MS Song", Font.PLAIN, fontSize);
        g.setFont(font);
//        for(int i = 1; i<=4; i++) {
//        	g.drawLine(1, 25*i, 37*2, 25*i);
//        }
//        for(int i = 1; i<3; i++) {
//        	g.drawLine(37*i, 1, 37*i, 125);
//        }
        
        g.drawLine(37*2, 1, 37*2, 125);
        
        Font fonts = new Font("MS Song", Font.BOLD, 90);
        g.setFont(fonts);
        if(index<0||index>englist.size()){
        	index = 0;
        }
        g.drawString((String)englist.get(index), 5, 25*4);
//        for(int i = 0 ;i<10; i++) {
//        	int whichRowY = (int) Math.floor(i/2);
//        	int whichRowX = i%2==1?1:0;
//        	Double SAX = 37*(whichRowX+0.4);
//        	Double SAY = 25*(whichRowY+0.8);
//        	if(index== i+1) {
//            	g.fillRect(37*whichRowX+1, 25*whichRowY+1, 37-1, 25-1);
//            	g.setColor(WhiteRGB);
//            	g.drawString((String)englist.get(i), SAX.intValue(), SAY.intValue());
//            	g.setColor(BlackRGB);
//            }else {
//            	g.drawString((String)englist.get(i), SAX.intValue(), SAY.intValue());
//            }
//        }
        fonts = new Font("MS Song", Font.BOLD, 16);
        g.setFont(fonts);
        
        Double catex = 37*2.5;
        Double catey = 25*0.9;
        g.drawString(cateStr1, catex.intValue(), catey.intValue());
        
        Double cate2x = 37*2.5;
        Double cate2y = 25*1.9;
        g.drawString(cateStr2, cate2x.intValue(), cate2y.intValue());
        
        Double barx = 37*2.2;
        Double bary = 25*2.3;
        Double barw = 296-37*2.5;
        Double barh = 128-25*2.5;
        g.setRenderingHint( RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON );
        g.drawImage((Image)ServerCommon.barcode(barStr,"128"), barx.intValue(), bary.intValue(), barw.intValue(), barh.intValue(), null);
        
        g.dispose();
        
		return bimg;
	}
	
	public static BufferedImage barcode(String msg,String type) {
		AbstractBarcodeBean bean;
		switch (type) {
			case "128":
				bean = new Code128Bean();
				break;
			case "39":
				bean = new Code39Bean();
				break;
			default:
				bean = new Code128Bean();
				break;
		}
		bean.setModuleWidth(UnitConv.in2mm(2.8f / 160));
		BitmapCanvasProvider provider = new BitmapCanvasProvider(
			    300, BufferedImage.TYPE_BYTE_GRAY, true, 0);
		bean.generateBarcode(provider, msg);
			try {
				provider.finish();
			} catch (IOException e) {
				e.printStackTrace();
			}
		BufferedImage barcodeImage = provider.getBufferedImage();
		return barcodeImage;
	}
	
	
	public static JSONObject getJsonFromMap(Map<String, Object> map) throws JSONException {
	    JSONObject jsonData = new JSONObject();
	    for (String key : map.keySet()) {
	        Object value = map.get(key);
	        if (value instanceof Map<?, ?>) {
	            value = getJsonFromMap((Map<String, Object>) value);
	        }
	        jsonData.put(key, value);
	    }
	    return jsonData;
	}
	
	public static Map<String,Object> getMapFromJson(String str) throws JsonParseException, JsonMappingException, IOException{
		HashMap<String,Object> result =
		        new ObjectMapper().readValue(str, HashMap.class);
		return result;
	}
	
	
}
