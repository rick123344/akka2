package com.rick.model;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;

public class DSCASSANDRA{
    private static String ip = "10.8.1.122";
	private static String keyspace = "ds";
	private static int port = 9042;
	private static Cluster cluster = null;
	private static Session session = null;

    public DSCASSANDRA(){
        
    }

    public static Session getSession() {
    	return session;
    }
    
    public static void checkNull() {
    	if(session == null) {
    		cluster = Cluster.builder().addContactPoints(ip).withPort(port).build();
    		session = cluster.connect(keyspace);
    	}
    	if(session.isClosed()) {
    		session = cluster.connect(keyspace);
    	}
    }
    
    public static ResultSet readRecord(String statement,Object... param){
        checkNull();
    	// List<Object> re = new ArrayList<>();
        PreparedStatement IM = session.prepare(statement);
        ResultSet rs = session.execute(IM.bind(param));
		//String cqlStatement = "SELECT * FROM local";
        // for (Row row : session.execute(IM.bind(param))) {
        //     // System.out.println(row.getString(0));
        //     // re.add(row);
		// }
        session.close();
        return rs;
	}

}
