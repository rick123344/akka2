package com.rick.model;

import java.util.Calendar;
import java.util.List;
import java.util.UUID;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;

public class DeviceData {
	
	public List getResult() {
		Calendar c = Calendar.getInstance();
		long year = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH)+1;
		ResultSet rs = DSCASSANDRA.readRecord("SELECT * FROM deviceData WHERE slaveid=? and year=? and month=? limit 1;", UUID.fromString("c4db0b30-bac6-11e7-9fc8-4ef193934fd2"),year,month);
		 for (Row row : rs) {
             System.out.println(row.getObject("slaveid"));
             System.out.println(row.getObject("data"));
		 }
		return null;
	}
}
// c4db0b30-bac6-11e7-9fc8-4ef193934fd2