package com.rick;
import org.apache.log4j.Logger;

import com.rick.model.DeviceData;

public class Startup{

    private static Logger logger = Logger.getLogger(Startup.class);

    public Startup(){
    	DeviceData dd = new DeviceData();
    	dd.getResult();
    }
}
