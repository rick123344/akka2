Run application with gradle or java application

----> gradle ----->
1. install gradle in host (https://gradle.org/install/#manually) , download and install , set Environment variable to bin folder
2. install gradle in eclipse , marketplace search "Gradle IDE Pack" and install , restart. //required
用eclipse marketplace 搜尋 Gradle IDE Pack 安裝並重啟



----> run application ---->
Eclipse:
	a. File->Open Project From File System...->Directory(choose akka1 root)->Finish
	b. Right click on akka1 project, Configure->Convert to Gradle(STS) Project
	c. Right click again , you will found Gradle(STS) is show-> Refresh All
	d. Right click again , Run As -> Gradle(STS) build-> Enter "clean run" in Gradle Task window. -> Run
	e. Enjoy~


Command(must install gradle in hose and set environment):
	1. open a cmd
	2. cd to akka1 folder that conatin build.gradle
	3. enter "gradle clean run" to run application or "gradle clean build" to build jar
	4. enjoy~

	


----> file path ----->
1. Main.java in src/main/java/com/rick/Main.java
2. akka config file in src/main/resources/application.conf

	
----> Others ---->
1. build.gradle will help you to manage dependency. Just append extra dependency inside dependencies{}, gradle will download and set automatically.


----> Notice ---->
1. 兩個專案不分誰是server,純粹akka1有開啟remote path可讓其他人送資料
2. 兩個專案內容大部分都相同
3. application.conf的host更改為您的本機IP
4. 此範例為基本akka使用及remote遠端送訊息DEMO






