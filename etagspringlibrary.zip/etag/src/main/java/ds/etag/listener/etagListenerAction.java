package ds.etag.listener;

import java.util.ArrayList;
import java.util.List;

import ds.etag.model.RespObj;

public class etagListenerAction{
	private List<etagListener> listeners = new ArrayList<etagListener>();

    public void addListener(etagListener toAdd) {
        listeners.add(toAdd);
    }

    public void sendResponse(RespObj obj) {
        for (etagListener hl : listeners)
            hl.etagResponse(obj);
    }
}
