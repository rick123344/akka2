package ds.etag.listener;

import ds.etag.model.RespObj;

public interface etagListener {
	void etagResponse(RespObj obj);
}
