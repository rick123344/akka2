package ds.etag.listener;

public interface timeoutListener {
	public void timeoutAction();
}
