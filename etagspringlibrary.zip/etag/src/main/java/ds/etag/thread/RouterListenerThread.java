package ds.etag.thread;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ds.etag.listener.etagListener;
import ds.etag.listener.etagListenerAction;
import ds.etag.model.EndDevice;
import ds.etag.model.RespObj;
import ds.etag.model.Router;
import ds.etag.repository.RoutersCollect;
import ds.etag.util.ActionType;
import ds.etag.util.Socket;

public class RouterListenerThread extends Thread implements etagListener{
	private static Logger logger = LoggerFactory.getLogger(RouterListenerThread.class);
	public static etagListenerAction el = new etagListenerAction();
	public static RouterListenerThread rlt= new RouterListenerThread();
	public static RoutersCollect rc = new RoutersCollect();
	
	public void run(){
		RouterListenerThread.addEtagListener(this);
		listenerStart();
	}
	public static void etagThreadStart() {
//		System.out.println(rlt.getState());
		if(!rlt.isAlive()) {
			rlt.start();
		}
	}
	public static void addEtagListener(etagListener obj) {
		el.addListener(obj);
	}
	public void listenerStart(){
		try{
			while(true){
				try {
					RespObj ro = Socket.receiveData();
					ro = ActionType.responseDismantle(ro);
					el.sendResponse((RespObj)ActionType.dismantleByType(ro));
				}catch(Exception e) {
					logger.error("Listener Error",e);
					e.printStackTrace();
				}
			}
		}catch(Exception e){
			logger.error("Socket Error! ",e);
		}
	}
	
	@Override
	public void etagResponse(RespObj obj) {
//		System.out.println("response"+obj);
		try {
			Router rt = RoutersCollect.getRouterByDeviceId(obj.getDeviceTmp().getId());
			EndDevice ed = rt.getDevices().get(obj.getDeviceTmp().getId());
			if(obj.getPacketType().equals ("08")&&ed.getUpdateImageType()==1) {
				if(obj.getStatus()==1) {//if response 4, lcd index the same, the image already exist
					ActionType.sendNextImageCommand(obj, ed, rt);
				}
			}
			if(obj.getPacketType().equals("09")&&ed.getUpdateImageType()==1) {
				ActionType.sendNextImageCommand(obj, ed, rt);
			} 
		}catch(Exception e) {
//			e.printStackTrace();
//			System.out.println(e.toString());
		}
		
	}
	
}
