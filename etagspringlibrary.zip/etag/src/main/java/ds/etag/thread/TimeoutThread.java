//not working ... just test...
package ds.etag.thread;

import java.util.Timer;
import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ds.etag.repository.RoutersCollect;

public class TimeoutThread{
	private static Logger logger = LoggerFactory.getLogger(TimeoutThread.class);
	
	protected long timer = 0;
	protected Thread thread;
	protected String name = "";
	protected Timer t;
	
	public TimeoutThread(String name,long timer) {
		this.timer = timer;
		this.name = name;
	}

	public void reCount() {
		destroy();
		startTimeout();
	}
	
	public void destroy(){
		try{
			thread.interrupt();
			t.cancel();
		}catch(Exception e){
			
		}
	}
	
	public void countDown(long timer) {
//		System.out.println(this.name+" CountDown ");
		t = new Timer(true);
		t.schedule(new TimerTask() {
			private String name;
			@Override
			public void run() {
				if(this.name.equals("routerList")) {
					RoutersCollect.clearRouters();
					logger.info(this.name+" Timeout..., Router No Response. Clean all devices");
				}
			}
			private TimerTask init(String name) {
				this.name = name;
				return this;
			}
		}.init(name),timer);
	}
	
	public void startTimeout() {
		thread = null;
		thread = new Thread() {
			private long timer = 0;
			@Override
			public void run() {
				try {
					countDown(this.timer);
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
			private Thread init(long timer) {
				this.timer = timer;
				return this;
			}
		}.init(this.timer);
		thread.start();
	}
	
	
}
