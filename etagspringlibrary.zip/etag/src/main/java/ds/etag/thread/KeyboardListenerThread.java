package ds.etag.thread;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ds.etag.listener.etagListener;
import ds.etag.listener.timeoutListener;
import ds.etag.model.EndDevice;
import ds.etag.model.RespObj;
import ds.etag.model.Router;
import ds.etag.repository.RoutersCollect;
import ds.etag.util.ActionType;
import ds.etag.util.Common;

public class KeyboardListenerThread extends Thread implements etagListener{
	private static Logger logger = LoggerFactory.getLogger(KeyboardListenerThread.class);
	private Router rt = new Router();
	private EndDevice ed = new EndDevice();
	
	public KeyboardListenerThread(){
		RouterListenerThread.addEtagListener(this);
	}
	
	public void run(){
		Common.showImage(Common.createImage("形體W PEGASUS + 1 ESS SU17 ID,150,部位:前面片/鞋身/鞋舌上層/鞋舌中層,4EV, 54H ,01V,00A,65N,46E,78A,00A,1000,6.52,8,7.5,8,8.5,555,9.5,2,6,55,2,5,7,8,2"));
		listenerStart();
	}
	
	public void test(timeoutListener tl){
		tl.timeoutAction();
	}
	
	public void listenerStart(){
		Scanner scanner = new Scanner(System.in);
		try{
			rt.setId("00174C57");
			rt.setIp("10.1.21.253");//192.168.30.10
			rt.setPort(50000);
			
			ed.setId("00000006");
			ed.setRouteId("00174C57");
			ed.getYellow().setStatus(0);
			ed.getWhite().setStatus(0);
			ed.getGreen().setStatus(0);
			ed.getGreen().setHighTime(0);
			ed.getGreen().setLowTime(0);
			ed.setSleepTime(10000);
			ed.setTimeout(3000);
//			byte[] img = Common.getImageGrayByte("C:\\Users\\rick.shih\\Downloads\\test.jpg");//Koala.jpg
			while(true){
				try {
					String ss= scanner.nextLine();
					if(ss.equals("checkImage")){
						ActionType.sendToCheckUpdateImage(ed, rt);
					}
					if(ss.equals("go")){
						ActionType.sendToUpdateImage(ed, rt);
					}
					if(ss.equals("light")){
						ActionType.sendToUpdateLedStatus(ed,rt);
					}
					if(ss.equals("yl")){
						String did = "00000006";
						Router r = RoutersCollect.getRouterByDeviceId(did);
						EndDevice ee = r.getDevices().get(did);
						ee.getYellow().setStatus(1);
						ActionType.sendToUpdateLedStatus(ee,r);
					}
					if(ss.equals("yc")){
						String did = "00000006";
						Router r = RoutersCollect.getRouterByDeviceId(did);
						EndDevice ee = r.getDevices().get(did);
						ee.getYellow().setStatus(0);
						ActionType.sendToUpdateLedStatus(ee,r);
					}
					if(ss.equals("device")) {
						ActionType.sendToGetDevicesByRouter(rt);
					}
					if(ss.equals("watchDevice")) {
						Iterator iterator = RoutersCollect.getRouters().entrySet().iterator();  
						while (iterator.hasNext()) {  
						Map.Entry mapEntry = (Map.Entry) iterator.next();  
						System.out.println("The key is: " + mapEntry.getKey()  
						+ ",value is :" + mapEntry.getValue());  
						}  
					}
					if(ss.equals("sleeptime")) {
						ActionType.sendToUpdateSleepTime(ed, rt);
					}
					if(ss.equals("image")) {
//						Common.showImage(Common.createImage());
					}
					if(ss.equals("oneput")) {
						String did = "00000006";
						Router r = RoutersCollect.getRouterByDeviceId(did);
						EndDevice ee = r.getDevices().get(did);
						ee.setUpdateImageType(0);
						ee.setData(Common.imageToStringArray(Common.createImageWithBarCode(8,"0123456789","MIT鍏ㄥ湴褰㈠皥妤窇闉�","閬块渿鏀彺-鍔涢噺鍨�")));
						ActionType.sendToUpdateImage(ee, r,30);
					}
					if(ss.equals("twoput")) {
						String did = "00000006";
						Router r = RoutersCollect.getRouterByDeviceId(did);
						EndDevice ee = r.getDevices().get(did);
						ee.setData(Common.imageToStringArray(Common.createImageWithBarCode(8,"0123456789","MIT鍏ㄥ湴褰㈠皥妤窇闉�","閬块渿鏀彺-鍔涢噺鍨�")));
						ee.setUpdateImageType(1);
						ActionType.sendToUpdateImage(ee, r);
					}
					if(ss.equals("empty")){
						String did = "00000006";
						Router r = RoutersCollect.getRouterByDeviceId(did);
						EndDevice ee = r.getDevices().get(did);
						ee.setData(Common.imageToStringArray(Common.createEmptyImage()));
						ActionType.sendToUpdateImage(ee, r);
					}
					if(ss.equals("ts")){
						String did = "00000006";
						Router r = RoutersCollect.getRouterByDeviceId(did);
						r.setBusy(true);
					}
					if(ss.equals("tc")){
						String did = "00000006";
						Router r = RoutersCollect.getRouterByDeviceId(did);
						r.setBusy(false);
					}
					if(ss.equals("tw")){
						String did = "00000006";
						Router r = RoutersCollect.getRouterByDeviceId(did);
						System.out.println(r.isBusy());
					}
				}catch(Exception ee) {
					ee.printStackTrace();
				}
			}
	    
		}catch(Exception e){
			logger.error("Error! ",e);
			e.printStackTrace();
		}finally{
			try {
				logger.info("Keyboard Closed");
			} catch (Exception e) {
				logger.error("Keyboard Close Error!",e);
			}
		}
	}
	@Override
	public void etagResponse(RespObj obj) {
//		System.out.println(obj);
//		logger.info(obj.toString());
	}
}
