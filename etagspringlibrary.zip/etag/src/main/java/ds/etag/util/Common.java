package ds.etag.util;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.xml.bind.DatatypeConverter;

public class Common {
	
	private final static char[] hexArray = "0123456789ABCDEF".toCharArray();
	private final static int imageMaxBytePerCommand = 64*2;
	// 296*128 => total 37888 bit, 4736 byte, each command only pass 64 byte
	// so this will have 7436 length, pass 74 times.
	// 37888/8
	private final static int imageWidth = 296;
	private final static int imageHeight = 128;
	private final static int byteSize = 8;
	private final static Color WhiteRGB = new Color(255, 255, 255);
	private final static int white = WhiteRGB.getRGB();
	private final static Color BlackRGB = new Color(0, 0, 0);
	private final static int black = BlackRGB.getRGB();
	
	public static String[] bytesToStringArray(byte[] bytes){
		return getSplitImageString(bytesToHex(bytes));
	}
	
	public static String[] imageToStringArray(BufferedImage b) throws IOException {
		return bytesToStringArray(getImageGrayByte(b));
	}
	
	public static String[] getCreateImageByText(String text) throws IOException {
		return bytesToStringArray(getByteByCreateImage(text));
	}
	
	public static String bytesToHex(byte[] bytes) {
	    char[] hexChars = new char[bytes.length * 2];
	    for ( int j = 0; j < bytes.length; j++ ) {
	        int v = bytes[j] & 0xFF;
	        hexChars[j * 2] = hexArray[v >>> 4];
	        hexChars[j * 2 + 1] = hexArray[v & 0x0F];
	    }
	    return new String(hexChars);
	}
	
	public static byte[] hexStringToByteArray(String s) {
	    int len = s.length();
	    byte[] data = new byte[len / 2];
	    for (int i = 0; i < len; i += 2) {
	        data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
	                             + Character.digit(s.charAt(i+1), 16));
	    }
	    return data;
	}
	
	public static String countCS(String hex){
		
		int len = hex.length();
		int result = 0;
		for(int i = 0; i< len; i+=2){
			String high = String.valueOf(hex.charAt(i));
			String low = String.valueOf(hex.charAt(i+1));
			result += Integer.parseInt(high+low,16);
		}
		//to hex string
		String CSALL = intToHexString(result,2);
		//get only last two char
		String CS = CSALL.length() > 2 ? CSALL.substring(CSALL.length() - 2) : CSALL;
		return CS;
	}
	
	public static String intToHexString(int num,int perc){
		perc = (perc==0)? 2:perc;
		String s = String.format("%0"+perc+"x", num).toUpperCase();
		return s;
	}
	
	public static String intToBinaryString(int num,int perc){
		perc = (perc==0)? 2:perc;
		String s = String.format("%"+perc+"s", Integer.toBinaryString(num)).replace(" ", "0");
		return s;
	}
	
	public static String[] getSplitImageString(String hex){
		//split string by every imageMaxBytePerCommand count(number)
		String[] splitStr = hex.split("(?<=\\G.{"+imageMaxBytePerCommand+"})");
		for(int in = 0; in<splitStr.length; in++){
			if(splitStr[in].length()!=imageMaxBytePerCommand){
				String tmp = "";
				for(int i = 0; i<imageMaxBytePerCommand-splitStr[in].length();i++){
					tmp+="0";
				}
				splitStr[in]+=tmp;
			}
		}
		return splitStr;
	}
	
	public static String base64UrlToHexStr(String imgurl) throws IOException{
		BufferedImage image = base64ToImage(imgurl);
		byte[] img = getImageGrayByte(image);
		return bytesToHex(img);
	}
	
	
	
	
	public static byte[] getByteByCreateImage(String text) throws IOException {
		BufferedImage o = createImage(text);
		byte[] img = getImageBytes(o);
		return img;
	}
	
	public static byte[] getImageGrayByte(String path) throws IOException{
		BufferedImage o = getImageBuffered(path);
		byte[] img = getImageBytes(o);
		return img;
	}
	public static byte[] getImageGrayByte(BufferedImage image) throws IOException{
		BufferedImage o = getImageBuffered(image);
		byte[] img = getImageBytes(o);
		return img;
	}
	
	public static BufferedImage getImageBuffered(String path) throws IOException{
		File f = new File(path);
		BufferedImage o =imageToGray(resizeImage(ImageIO.read(f)));
		return o;
	}
	public static BufferedImage getImageBuffered(BufferedImage image) throws IOException{
		BufferedImage o =imageToGray(resizeImage(image));
		return o;
	}
	
	public static byte[] getImageBytes(BufferedImage image) throws IOException{

		byte[] byteImage = new byte[image.getWidth()*image.getHeight()];
		for(int i = 0;i<image.getWidth();i++){
			for(int j = image.getHeight()-1; j>0; j--){
				int  clr = image.getRGB(i,j);
				if(clr==white){
					byteImage[i * 128 + (127 - j)] =0;
				}else{
					byteImage[i * 128 + (127 - j)] =1;
				}
			}
		}
		return resizeImageBytes(byteImage);
	}
	
	public static byte[] resizeImageBytes(byte[] byteImage){
		byte[] resize = new byte[byteImage.length/byteSize];
		for (int k = 0; k < byteImage.length; k++){
			if (byteImage[k] != 0){
				int cp = k / 8;
				resize[cp] |= (byte)(1 << 7 - k % 8);
			}
		}
//		System.out.println(Arrays.toString(resize));
		return resize; 
	}
	
	//pass in web application 
	public static byte[] getImageOrgBytes(String path) throws IOException{
		BufferedImage image = getImageBuffered(path);
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		//png support alpha channel, jpg not support, 
		//show on web must have alpha channel
		ImageIO.write( image, "png", baos );
		baos.flush();
		byte[] byteImage = baos.toByteArray();
		baos.close();
		return byteImage;
	}
	public static byte[] getImageOrgBytes(BufferedImage image) throws IOException{
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write( image, "png", baos );
		baos.flush();
		byte[] byteImage = baos.toByteArray();
		baos.close();
		return byteImage;
	}
	
	public static BufferedImage bytesToImage(byte[] bf) throws IOException{
		InputStream in = new ByteArrayInputStream(bf);
		BufferedImage bfi = ImageIO.read(in);
		return bfi;
	}
	
	public static BufferedImage resizeImage(BufferedImage image){
		BufferedImage resizedImage = new BufferedImage(imageWidth, imageHeight, image.getType());
		Graphics2D g = resizedImage.createGraphics();
		g.drawImage(image, 0, 0, imageWidth, imageHeight, null);
		g.dispose();
		return resizedImage;
	}
	
	public static BufferedImage imageToGray(BufferedImage image){
		for(int y = 0; y < image.getHeight(); y++){
			for(int x = 0; x < image.getWidth(); x++){
				int p = image.getRGB(x,y);
				int a = (p>>24)&0xff;
				int r = (p>>16)&0xff;
				int g = (p>>8)&0xff;
				int b = p&0xff;
				int avg = (r+g+b)/3;
				//replace RGB value with avg
//				p = (a<<24) | (avg<<16) | (avg<<8) | avg;
				if(avg>127){//127 135
					p = white;
				}else{
					p = black;
				}
				image.setRGB(x, y, p);
			}
		}
		return image;
	}
	
	public static BufferedImage base64ToImage(String imageString) throws IOException{
		BufferedImage image = null;
        byte[] imageByte;
        String base64Image = imageString.split(",")[1];
        imageByte = DatatypeConverter.parseBase64Binary(base64Image);
        image = ImageIO.read(new ByteArrayInputStream(imageByte));
        return image;
	}
	
	public static String imageToBase64(BufferedImage image) throws IOException{
		image =imageToGray(resizeImage(image));
		byte[] img = getImageOrgBytes(image);
		return DatatypeConverter.printBase64Binary(img);
	}
	
	public static void showImage(BufferedImage image) {
		JFrame frame=new JFrame();
		ImageIcon icon=new ImageIcon(image);
        frame.setSize(350,250);
        JLabel lbl=new JLabel();
        lbl.setIcon(icon);
        frame.add(lbl);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static BufferedImage createImageByText() {
		int fontSize = 12;
		BufferedImage bimg = new BufferedImage(296,128,BufferedImage.TYPE_INT_RGB);
		Graphics2D g = bimg.createGraphics();
        g.setColor(WhiteRGB); 
        g.fillRect(0, 0,296,128);
        
        g.setColor(BlackRGB);
        g.drawRect(1,1,293,125);
        Font font = new Font("MS Song", Font.PLAIN, fontSize);
        g.setFont(font);
        
        String info = "";
        String[] ss = info.split(",");
//        System.out.println(Arrays.toString(ss));
//        System.out.println(ss.length);
        
        g.drawString(ss[0]+" "+ss[1], 5, 20);
        g.setFont(new Font("MS Song", Font.BOLD, 25));
        g.drawString(ss[1], 240, 30);
        g.setFont(new Font("MS Song", Font.BOLD, fontSize));
        g.drawString(ss[2], 5, 45);
        
        for(int i = 2; i<=4; i++) {
        	g.drawLine(1, 25*i, 293, 25*i);
        }
        for(int i = 1; i<8; i++) {
        	g.drawLine(37*i, 50, 37*i, 125);
        }
        
        int startIndex = 3;
        for(int h=0; h<3; h++) {
        	for(int w=0; w<8; w++) {
        		g.drawString(ss[startIndex], 37*w+3, 50+18+25*h);
        		startIndex++;
        		if(startIndex>ss.length-1) {
        			break;
        		}
        	}
        }
        
        g.dispose();
        
		return bimg;
	}
	
	
	public static BufferedImage createImage(String text){
		String[] ss = new String[27];
		try{
			String[] temp = text.split("\\,",-1);
			for(int i = 0; i<ss.length;i++) {
				if(i>=temp.length) {
					ss[i] = "";
					continue;
				}
				ss[i] = temp[i];
			}
		}catch(Exception e) {
			for(int i = 0; i<27;i++) {
				ss[i] = "";
			}
		}
		
//        System.out.println(Arrays.toString(ss));
//        System.out.println(ss.length);
        
		int tableWidth = imageWidth-3;
		int tableHeight = imageHeight-3;
		int fontSize = 13;
		
		int lineHeight = tableHeight/5;
		int lineWidth = tableWidth/8;
		
		int spaceHeight = 5;
		int spaceWidth = 3;
		
		BufferedImage bimg = new BufferedImage(imageWidth,imageHeight,BufferedImage.TYPE_INT_RGB);
		Graphics2D g = bimg.createGraphics();
        g.setColor(WhiteRGB); 
        g.fillRect(0, 0,imageWidth,imageHeight);
        
        g.setColor(BlackRGB);
        g.drawRect(1,1,tableWidth,tableHeight);
        Font font = new Font("MS Song", Font.BOLD, fontSize);
        g.setFont(font);
        //set header
        g.drawString(ss[0], spaceWidth, lineHeight-spaceHeight);
        g.setFont(new Font("MS Song", Font.BOLD, 25));
//        g.drawString(ss[1], lineWidth*6+lineWidth/2, lineHeight+spaceHeight);
        g.drawString(ss[1], lineWidth*6+lineWidth/2, lineHeight);
        g.setFont(new Font("MS Song", Font.BOLD, fontSize));
        g.drawString(ss[2], spaceWidth, lineHeight*2-spaceHeight);
        //set month and day
        java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("MM/dd");
        String monthAndDay = format.format(new Date());
        g.drawString(monthAndDay, lineWidth*7, lineHeight*2-spaceHeight);
        
        //draw all lines
        for(int i = 2; i<=4; i++) {
        	g.drawLine(1, lineHeight*i, tableWidth, lineHeight*i);
        }
        for(int i = 1; i<8; i++) {
        	g.drawLine(lineWidth*i, lineHeight*2, lineWidth*i, tableHeight);
        }
        
        int startIndex = 3;
        for(int h=0; h<3; h++) {
        	for(int w=0; w<8; w++) {
        		String slen = ss[startIndex];
        		slen = slen.replaceAll("\\.", "");
        		//len>=4 doesn't need to fix
        		int fixcenter = 0;
        		//len = 1, half lineWidth and cut spaceWidth 
        		if(slen.length()<=1) {
        			fixcenter = lineWidth/2-spaceWidth*2;
        		}
        		//len = 2
        		if(slen.length()==2) {
        			fixcenter = lineWidth/2-(spaceWidth*2)-(lineWidth/8);
        		}
        		//len = 3
        		if(slen.length()==3) {
        			fixcenter = lineWidth/4-spaceWidth*2;
        		}
        		g.drawString(ss[startIndex], lineWidth*w+spaceWidth+fixcenter, lineHeight*2+lineHeight/2+spaceHeight+lineHeight*h);
        		startIndex++;
        		if(startIndex>ss.length-1) {
        			break;
        		}
        	}
        }
        
        g.dispose();
//        showImage(bimg);
		return bimg;
	}


	public static BufferedImage createImageWithBarCode(int index,String barStr,String cateStr1,String cateStr2) {
		List englist = Arrays.asList("A","B","C","D","E","F","G","H","I","J");	
//		Color WhiteRGB = new Color(255, 255, 255);
//		int white = WhiteRGB.getRGB();
//		Color BlackRGB = new Color(0, 0, 0);
//		int black = BlackRGB.getRGB();
		int fontSize = 12;
		BufferedImage bimg = new BufferedImage(296,128,BufferedImage.TYPE_INT_RGB);
		Graphics2D g = bimg.createGraphics();
        g.setColor(WhiteRGB); 
        g.fillRect(0, 0,296,128);
        
        g.setColor(BlackRGB);
        g.drawRect(1,1,293,125);
        Font font = new Font("MS Song", Font.PLAIN, fontSize);
        g.setFont(font);
//        for(int i = 1; i<=4; i++) {
//        	g.drawLine(1, 25*i, 37*2, 25*i);
//        }
//        for(int i = 1; i<3; i++) {
//        	g.drawLine(37*i, 1, 37*i, 125);
//        }
        
        g.drawLine(37*2, 1, 37*2, 125);
        
        Font fonts = new Font("MS Song", Font.BOLD, 90);
        g.setFont(fonts);
        
        g.drawString("B", 5, 25*4);
//        for(int i = 0 ;i<10; i++) {
//        	int whichRowY = (int) Math.floor(i/2);
//        	int whichRowX = i%2==1?1:0;
//        	Double SAX = 37*(whichRowX+0.4);
//        	Double SAY = 25*(whichRowY+0.8);
//        	if(index== i+1) {
//            	g.fillRect(37*whichRowX+1, 25*whichRowY+1, 37-1, 25-1);
//            	g.setColor(WhiteRGB);
//            	g.drawString((String)englist.get(i), SAX.intValue(), SAY.intValue());
//            	g.setColor(BlackRGB);
//            }else {
//            	g.drawString((String)englist.get(i), SAX.intValue(), SAY.intValue());
//            }
//        }
        fonts = new Font("MS Song", Font.BOLD, 16);
        g.setFont(fonts);
        
        Double catex = 37*2.5;
        Double catey = 25*0.9;
        g.drawString(cateStr1, catex.intValue(), catey.intValue());
        
        Double cate2x = 37*2.5;
        Double cate2y = 25*1.9;
        g.drawString(cateStr2, cate2x.intValue(), cate2y.intValue());
        
        Double barx = 37*2.2;
        Double bary = 25*2.3;
        Double barw = 296-37*2.5;
        Double barh = 128-25*2.5;
        g.setRenderingHint( RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON );
        g.drawImage((Image)Common.barcode(barStr,"128"), barx.intValue(), bary.intValue(), barw.intValue(), barh.intValue(), null);
        
        g.dispose();
        
		return bimg;
	}
	
	public static BufferedImage barcode(String msg,String type) {
//		AbstractBarcodeBean bean;
//		switch (type) {
//			case "128":
//				bean = new Code128Bean();
//				break;
//			case "39":
//				bean = new Code39Bean();
//				break;
//			default:
//				bean = new Code128Bean();
//				break;
//		}
//		bean.setModuleWidth(UnitConv.in2mm(2.8f / 160));
//		BitmapCanvasProvider provider = new BitmapCanvasProvider(
//			    300, BufferedImage.TYPE_BYTE_GRAY, true, 0);
//		bean.generateBarcode(provider, msg);
//			try {
//				provider.finish();
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		BufferedImage barcodeImage = provider.getBufferedImage();
		BufferedImage barcodeImage = null;
		return barcodeImage;
	}
	
	public static BufferedImage createEmptyImage(){
		BufferedImage bimg = new BufferedImage(imageWidth,imageHeight,BufferedImage.TYPE_INT_RGB);
		Graphics2D g = bimg.createGraphics();
        g.setColor(WhiteRGB); 
        g.fillRect(0, 0,imageWidth,imageHeight);
        return bimg;
	}
	
}
