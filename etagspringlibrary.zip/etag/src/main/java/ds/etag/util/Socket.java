package ds.etag.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import ds.etag.model.RespObj;

public class Socket {
	public static DatagramSocket sendSocket=null;
	public static DatagramSocket receiveSocket=null;
	public static int serverPort = 8523;
	
	public static byte[] sendData(DatagramPacket sendPacket) throws IOException{
		sendSocket = new DatagramSocket();
		byte[] result = new byte[0];
		if(sendSocket!=null){
			sendSocket.send(sendPacket);
			try{
				sendSocket.close();
			}catch(Exception e){
				
			}
		}
		return result;
	}
	
	public static void checkNullSocket() throws SocketException{
		try{
			if(receiveSocket==null){
				receiveSocket = new DatagramSocket(serverPort);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static RespObj receiveData() throws IOException{
		checkNullSocket();
		
		byte[] receiveData = new byte[1024];
		DatagramPacket dp = new DatagramPacket(receiveData, receiveData.length);
		receiveSocket.receive(dp);
//		long totalTime = System.nanoTime();
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		baos.write(receiveData,0,dp.getLength());
		byte[] result = baos.toByteArray();
		RespObj obj = new RespObj();
		obj.setSource(result);
		obj.setIp(dp.getAddress().getHostAddress());
		obj.setPort(dp.getPort());
//		System.out.println(TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-totalTime));
		return obj;
	}
	
}
