package ds.etag.util;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import ds.etag.model.EndDevice;
import ds.etag.model.Light;
import ds.etag.model.RespObj;
import ds.etag.model.Router;
import ds.etag.repository.RoutersCollect;

public class ActionType {
	
	private static String commandBegin = "ED";
	private static String commandEnd = "EC";
	
	// prepare command 
	public static String commandGetDevicesByRouter(String routerId){
		String commandType = "15";
		String hex = commandBegin+commandType+routerId;
		hex = (hex+Common.countCS(hex)+commandEnd).toUpperCase();
//		System.out.println(hex);
		return hex;
	}
	
	public static String commandUpdateSleepTime(String routerId,String deviceId,int sleepTime,int timeout){
		String commandType = "06";
		String hex = commandBegin+commandType+routerId+Common.intToHexString(sleepTime, 4)+Common.intToHexString(timeout, 8);
		hex = (hex+Common.countCS(hex)+commandEnd).toUpperCase();
		return hex;
	}
	
	public static String commandUpdateLedStatus(EndDevice ed){
		String commandType = "07";
		// 0000 0000 0000 0000
		// yellow,green,blue,white,red
//		System.out.println(ed);
		String lightState="";
		String lightTime="";
		
		lightState+=Common.intToBinaryString(ed.getYellow().getStatus(), 8);
		lightState+=Common.intToBinaryString(ed.getGreen().getStatus(), 2);
		lightState+=Common.intToBinaryString(ed.getBlue().getStatus(), 2);
		lightState+=Common.intToBinaryString(ed.getWhite().getStatus(), 2);
		lightState+=Common.intToBinaryString(ed.getRed().getStatus(), 2);
		//convert binary string to hex string
		lightState = Common.intToHexString(Integer.parseInt(lightState,2), 4);
		
		lightTime+=Common.intToHexString(ed.getYellow().getHighTime(), 4);
		lightTime+=Common.intToHexString(ed.getYellow().getLowTime(), 4);
		lightTime+=Common.intToHexString(ed.getGreen().getHighTime(), 4);
		lightTime+=Common.intToHexString(ed.getGreen().getLowTime(), 4);
		lightTime+=Common.intToHexString(ed.getBlue().getHighTime(), 4);
		lightTime+=Common.intToHexString(ed.getBlue().getLowTime(), 4);
		lightTime+=Common.intToHexString(ed.getWhite().getHighTime(), 4);
		lightTime+=Common.intToHexString(ed.getWhite().getLowTime(), 4);
		lightTime+=Common.intToHexString(ed.getRed().getHighTime(), 4);
		lightTime+=Common.intToHexString(ed.getRed().getLowTime(), 4);
		String hex = commandBegin+commandType+ed.getRouteId()+ed.getId()+lightState+lightTime+Common.intToHexString(3000, 8);
		hex = (hex+Common.countCS(hex)+commandEnd).toUpperCase();
//		System.out.println(hex);
		return hex;
	}
	
	public static String commandAskingForUpdateLcdImage(EndDevice ed){
		String commandType = "08";
		String hex = commandBegin+commandType+ed.getRouteId()+ed.getId();
		hex += Common.intToHexString(ed.getLcdIndex(), 2);
		int timeout = ed.getTimeout();
		if(timeout==0||new Integer(timeout)==null){
			timeout = 3000;
		}
		hex += Common.intToHexString(timeout, 8);
		hex = (hex+Common.countCS(hex)+commandEnd).toUpperCase();
//		System.out.println(hex);
		return hex;
	}
	
	public static String commandUpdateLcdImage(EndDevice ed,int index){
		String commandType = "09";
		String hex = commandBegin+commandType+ed.getRouteId()+ed.getId();
		
		hex += Common.intToHexString(ed.getLcdIndex(), 2);
		hex += Common.intToHexString(ed.getAddress(), 4);
		String dh = ed.getData()[index];
		hex += dh;
		hex = (hex+Common.countCS(hex)+commandEnd).toUpperCase();
//		System.out.println(hex);
		return hex;
	}
	
	
	// Action send to update
	
	public static void sendToGetDevicesByRouter(Router rt) throws IOException, InterruptedException {
		doSend(rt,commandGetDevicesByRouter(rt.getId()));
	}
	
	public static void sendToUpdateSleepTime(EndDevice ed,Router rt) throws IOException, InterruptedException {
		doSend(rt,commandUpdateSleepTime(rt.getId(),ed.getId(),ed.getSleepTime(),ed.getTimeout()));
		RoutersCollect.setBusyByRouterId(rt.getId(), true);
	}
	
	public static void sendToUpdateImage(EndDevice ed,Router rt) throws IOException, InterruptedException{
		updateImage(ed,rt,50,true);
	}
	public static void sendToUpdateImage(EndDevice ed,Router rt,boolean setlcdindex) throws IOException, InterruptedException{
		updateImage(ed,rt,50,setlcdindex);
	}
	public static void sendToUpdateImage(EndDevice ed,Router rt,int timer) throws IOException, InterruptedException{
		updateImage(ed,rt,timer,true);
	}
	public static void sendToUpdateImage(EndDevice ed,Router rt,int timer,boolean setlcdindex) throws IOException, InterruptedException{
		updateImage(ed,rt,timer,setlcdindex);
	}
	private static void updateImage(EndDevice ed,Router rt,int timer,boolean setlcdindex) throws IOException, InterruptedException {
		if(setlcdindex){
			ed.setLcdIndex();
		}
		sendToCheckUpdateImage(ed,rt);
		int updateImageType = ed.getUpdateImageType();
		if(updateImageType!=0&&updateImageType!=1) {
			ed.setUpdateImageType(0);
		}
		RoutersCollect.setBusyByRouterId(rt.getId(), true);
		InetAddress ip = InetAddress.getByName(rt.getIp());
		if(ed.getUpdateImageType()==0) {
			// 74 times
			for(int i = 0; i<ed.getData().length;i++){
				byte[] sendData = Common.hexStringToByteArray(ActionType.commandUpdateLcdImage(ed,i));
				DatagramPacket sendPackage = new DatagramPacket(sendData,sendData.length,ip,rt.getPort());
				Socket.sendData(sendPackage);
				ed.addrNext();
				Thread.sleep(timer);
			}
			ed.resetAddr();
		}
	}
	public static void sendNextImageCommand(RespObj obj,EndDevice ed,Router rt) throws IOException, InterruptedException {
		if(obj.getPacketType().equals("08")&&obj.getStatus()==1) {
			String comm = commandUpdateLcdImage(ed,ed.getAddress()/64);
			doSend(rt,comm);
		}else if(obj.getPacketType().equals("09")) {
			ed.setAddress(obj.getDeviceTmp().getAddress()+64);
			String comm = commandUpdateLcdImage(ed,ed.getAddress()/64);
			doSend(rt,comm);
		}
		RoutersCollect.setBusyByRouterId(rt.getId(), true);
		if(ed.getAddress() == ed.getData().length*64) {
			ed.resetAddr();
		}
	}
	
	public static void sendToCheckUpdateImage(EndDevice ed,Router rt) throws IOException, InterruptedException{
		RoutersCollect.setBusyByRouterId(rt.getId(), true);
		doSend(rt,ActionType.commandAskingForUpdateLcdImage(ed));
		Thread.sleep(50);
	}
	
	public static void sendToUpdateLedStatus(EndDevice ed,Router rt) throws IOException, InterruptedException{
		doSend(rt,ActionType.commandUpdateLedStatus(ed));
		RoutersCollect.setBusyByRouterId(rt.getId(), true);
	}
	
	public static void doSend(Router rt,String command) throws IOException, InterruptedException{
		byte[] sendData = Common.hexStringToByteArray(command);
		InetAddress ip = InetAddress.getByName(rt.getIp());
		DatagramPacket sendPackage = new DatagramPacket(sendData,sendData.length,ip,rt.getPort());
//		System.out.println(sendPackage.toString());
//		System.out.println(sendPackage.getAddress());
		Socket.sendData(sendPackage);
	}
	
	// Response analogy
	public static RespObj responseDismantle(RespObj result){
		String hex = Common.bytesToHex(result.getSource());
		if(hex.length()<=8){
			result.setPass(false);
			result.setMessage("Response Length Confuse or No Extra Data Response.");
			return result;
		}
		if(!hex.substring(0,2).equals(result.getRespBegin())||!hex.substring(hex.length()-2).equalsIgnoreCase(result.getRespEnd())){
			result.setPass(false);
			result.setMessage("Response Begin or End prefix error.");
			return result;
		}
		String packetData = hex.substring(4,hex.length()-4);
		result.setPacketData(packetData);
		result.setPacketType(hex.substring(2,4));
		result.setCSCheck(hex.substring(hex.length()-4,hex.length()-2));
		return result;
	}
	
	public static Object dismantleByType(RespObj obj){
		String type = obj.getPacketType();
		if(type.equals("C1")){ //Router send it's own info to server
			obj.setBaseType("RouterIn");
			obj.setRouters(analogyRouterInfo(obj));
		}else if(type.equals("15")){ //Router send devices to server( send not only one time)
			obj.setBaseType("AllDevice");
			obj.setEndDevices(analogyDeviceInfo(obj));
		}else if(type.equals("81")){ //Router send new device is connected info to server
			obj.setBaseType("NewDevice");
			obj.setEndDevices(analogyNewDeviceOrChange(obj));
		}else if(type.equals("82")){ //Router send device status has changed to server
			obj.setBaseType("DeviceStatusChange");
			obj.setEndDevices(analogyNewDeviceOrChange(obj));
		}else if(type.equals("06")){ //Router send if receive the command to update sleepTime 
			obj.setBaseType("SleepTimeCommand");
			analogyReceiveSleepTimeCommand(obj);
		}else if(type.equals("84")){ //Router send update sleepTime success
			obj.setBaseType("SleepTimeSuccess");
			analogySuccessUpdateSleepTime(obj);
//			RoutersCollect.setBusyByRouterId(obj.getRouterId(), false);
		}else if(type.equals("C3")){ //Router send update sleepTime fail
			obj.setBaseType("SleepTimeFail");
			analogyFailUpdateSleepTime(obj);
//			RoutersCollect.setBusyByRouterId(obj.getRouterId(), false);
		}else if(type.equals("07")){ //Router send if receive the command to update LED
			obj.setBaseType("LEDCommand");
			analogyReceiveLEDCommand(obj);
		}else if(type.equals("85")){ //Router send update LED success
			obj.setBaseType("LEDSuccess");
			analogyReceiveLEDCommand(obj);
//			RoutersCollect.setBusyByRouterId(obj.getRouterId(), false);
		}else if(type.equals("C5")){ //Router send update LED fail
			obj.setBaseType("LEDFail");
			analogyReceiveLEDCommand(obj);
//			RoutersCollect.setBusyByRouterId(obj.getRouterId(), false);
		}else if(type.equals("08")){ //Router send status whether server can update image
			obj.setBaseType("AskImageUpdate");
			analogyLCDUpdateStatusCommand(obj);
//			if(obj.getStatus()==4) {
//				obj.setPacketType("83");
//				obj.setBaseType("LCDSuccess");
//			}
//			RoutersCollect.setBusyByRouterId(obj.getRouterId(), false);
		}else if(type.equals("09")){ //Router send if receive the command to update LCD
			obj.setBaseType("LCDCommand");
			analogySendLCDCommand(obj);
//			RoutersCollect.setBusyByRouterId(obj.getRouterId(), false);
		}else if(type.equals("83")){ //Router send update LCD success
			obj.setBaseType("LCDSuccess");
			analogySendLCDCommand(obj);
//			RoutersCollect.setBusyByRouterId(obj.getRouterId(), false);
		}else if(type.equals("C2")){ //Router send update LCD fail
			obj.setBaseType("LCDFail");
			analogySendLCDCommand(obj);
//			RoutersCollect.setBusyByRouterId(obj.getRouterId(), false);
		}else{ //unknow command type
			obj.setPass(false);
			obj.setMessage("PacketType Unknow...");
		}
		return obj;
	}
	
	public static Router analogyRouterInfo(RespObj obj){
		Router nr = new Router();
		String hex = obj.getPacketData();
		nr.setId(hex.substring(0,8));
		nr.setSendInfoTime(Integer.valueOf(hex.substring(hex.length()-2),16));
		
		nr.setIp(obj.getIp());
		nr.setPort(obj.getPort());
		return nr;
	}
	
	public static Map<String,EndDevice> analogyDeviceInfo(RespObj obj){
		Map<String,EndDevice> m = new HashMap<String,EndDevice>();
		String hex = obj.getPacketData();
		String routerid = hex.substring(0,8);
		obj.setRouterId(routerid);
		int count = Integer.valueOf(hex.substring(8,10),16);
		obj.setEndDeviceCount(count);
		if(count>0) {
			String newhex = hex.substring(10);
			String[] splitStr = newhex.split("(?<=\\G.{28})");
			for(String s : splitStr) {
//				System.out.println(s);
				EndDevice ed = new EndDevice();
				ed.setRouteId(routerid);
				ed.setId(s.substring(0, 8));
				ed.setSleepTime(Integer.valueOf(s.substring(8,12),16));
				ed.setLcdIndex(Integer.valueOf(s.substring(12,14),16));
				ed.setBattery(Integer.valueOf(s.substring(14,16),16));
				String ledString = Common.intToBinaryString(Integer.valueOf(s.substring(16,20),16), 16);
				ed.setLedType(ledString.substring(0,1).equals("1")? "ETag":"SignalTower");
				ed.setYellow(new Light(Integer.valueOf(ledString.substring(6,8),2)));
				ed.setGreen(new Light(Integer.valueOf(ledString.substring(8,10),2)));
				ed.setBlue(new Light(Integer.valueOf(ledString.substring(10,12),2)));
				ed.setWhite(new Light(Integer.valueOf(ledString.substring(12,14),2)));
				ed.setRed(new Light(Integer.valueOf(ledString.substring(14,16),2)));
				ed.setConnectTime(Integer.valueOf(s.substring(20),16));
				m.put(ed.getId(),ed);
			}
			
		}else {
//			System.out.println("deviceEnd");
		}
		
		return m;
	}
	
	public static Map<String,EndDevice> analogyNewDeviceOrChange(RespObj obj){
		Map<String,EndDevice> m = new HashMap<String,EndDevice>();
		EndDevice ed = new EndDevice();
		String hex = obj.getPacketData();
		String routerid = hex.substring(0,8);
		obj.setRouterId(routerid);
		ed.setRouteId(routerid);
		ed.setId(hex.substring(8, 16));
		ed.setBattery(Integer.valueOf(hex.substring(16,18),16));
		ed.setSleepTime(Integer.valueOf(hex.substring(18,22),16));
		ed.setLcdIndex(Integer.valueOf(hex.substring(22,24),16));
		String ledString = Common.intToBinaryString(Integer.valueOf(hex.substring(24,28),16), 16);
		ed.setLedType(ledString.substring(0,1).equals("1")? "ETag":"SignalTower");
		ed.setYellow(new Light(Integer.valueOf(ledString.substring(6,8),2)));
		ed.setGreen(new Light(Integer.valueOf(ledString.substring(8,10),2)));
		ed.setBlue(new Light(Integer.valueOf(ledString.substring(10,12),2)));
		ed.setWhite(new Light(Integer.valueOf(ledString.substring(12,14),2)));
		ed.setRed(new Light(Integer.valueOf(ledString.substring(14,16),2)));
		m.put(ed.getId(), ed);
		return m;
	}
	
	public static void analogyReceiveSleepTimeCommand(RespObj obj) {
		String hex = obj.getPacketData();
		String routerid = hex.substring(0,8);
		obj.setRouterId(routerid);
		EndDevice ed = new EndDevice();
		ed.setId(hex.substring(8,16));
		ed.setSleepTime(Integer.valueOf(hex.substring(16,20),16));
		ed.setTimeout(Integer.valueOf(hex.substring(20,28),16));
		obj.setDeviceTmp(ed);
		int status = Integer.valueOf(hex.substring(28,30),16);
		obj.setStatus(status);
		if(status==1) {
			obj.setMessage("Router receive update sleeptime command success.");
		}else if(status==2) {
			obj.setMessage("Memory cache is full currently,can't be update.");
		}else if(status==3) {
			obj.setMessage("The EndDevice not conntect to Router: "+routerid+", can't be update.");
		}
	}
	
	public static void analogySuccessUpdateSleepTime(RespObj obj) {
		String hex = obj.getPacketData();
		String routerid = hex.substring(0,8);
		obj.setRouterId(routerid);
		EndDevice ed = new EndDevice();
		ed.setId(hex.substring(8,16));
		ed.setSleepTime(Integer.valueOf(hex.substring(16,20),16));
		obj.setDeviceTmp(ed);
		obj.setMessage("Update EndDevice "+obj.getDeviceTmp().getId()+" sleep time success.");
	}
	
	public static void analogyFailUpdateSleepTime(RespObj obj) {
		String hex = obj.getPacketData();
		String routerid = hex.substring(0,8);
		obj.setRouterId(routerid);
		EndDevice ed = new EndDevice();
		ed.setId(hex.substring(8,16));
		ed.setSleepTime(Integer.valueOf(hex.substring(16,20),16));
		obj.setDeviceTmp(ed);
		obj.setMessage("Update EndDevice "+obj.getDeviceTmp().getId()+" sleep time fail.");
	}
	
	public static void analogyReceiveLEDCommand(RespObj obj) {
		String hex = obj.getPacketData();
		String routerid = hex.substring(0,8);
		obj.setRouterId(routerid);
		EndDevice ed = new EndDevice();
		ed.setId(hex.substring(8,16));
		String ledString = Common.intToBinaryString(Integer.valueOf(hex.substring(16,20),16), 16);
		ed.setLedType(ledString.substring(0,1).equals("1")? "ETag":"SignalTower");
		ed.setYellow(new Light(Integer.valueOf(ledString.substring(6,8),2)));
		ed.setGreen(new Light(Integer.valueOf(ledString.substring(8,10),2)));
		ed.setBlue(new Light(Integer.valueOf(ledString.substring(10,12),2)));
		ed.setWhite(new Light(Integer.valueOf(ledString.substring(12,14),2)));
		ed.setRed(new Light(Integer.valueOf(ledString.substring(14,16),2)));
		ed.getYellow().setHighTime(Integer.valueOf(hex.substring(20,24),16));
		ed.getYellow().setLowTime(Integer.valueOf(hex.substring(24,28),16));
		ed.getGreen().setHighTime(Integer.valueOf(hex.substring(28,32),16));
		ed.getGreen().setLowTime(Integer.valueOf(hex.substring(32,36),16));
		ed.getBlue().setHighTime(Integer.valueOf(hex.substring(36,40),16));
		ed.getBlue().setLowTime(Integer.valueOf(hex.substring(40,44),16));
		ed.getWhite().setHighTime(Integer.valueOf(hex.substring(44,48),16));
		ed.getWhite().setLowTime(Integer.valueOf(hex.substring(48,52),16));
		ed.getRed().setHighTime(Integer.valueOf(hex.substring(52,56),16));
		ed.getRed().setLowTime(Integer.valueOf(hex.substring(56,60),16));
		obj.setDeviceTmp(ed);
		if(obj.getPacketType().equals("07")) {
			ed.setTimeout(Integer.valueOf(hex.substring(60,68),16));
			int status = Integer.valueOf(hex.substring(68,70),16);
			obj.setStatus(status);
			if(status==1) {
				obj.setMessage("Router receive update LED command success.");
			}else if(status==2) {
				obj.setMessage("Memory cache is full currently,can't be update.");
			}else if(status==3) {
				obj.setMessage("The EndDevice not conntect to Router: "+routerid+", can't be update.");
			}
		}else if(obj.getPacketType().equals("85")) {
			obj.setMessage("Update EndDevice "+obj.getDeviceTmp().getId()+" LED Success");
		}else if(obj.getPacketType().equals("C5")) {
			obj.setMessage("Update EndDevice "+obj.getDeviceTmp().getId()+" LED fail");
		}
	}
	
	public static void analogyLCDUpdateStatusCommand(RespObj obj) {
		String hex = obj.getPacketData();
		String routerid = hex.substring(0,8);
		obj.setRouterId(routerid);
		EndDevice ed = new EndDevice();
		ed.setId(hex.substring(8,16));
		ed.setLcdIndex(Integer.valueOf(hex.substring(16,18),16));
		ed.setTimeout(Integer.valueOf(hex.substring(18,26),16));
		int status = Integer.valueOf(hex.substring(26,28),16);
		obj.setStatus(status);
		obj.setDeviceTmp(ed);
		if(status==1) {
			obj.setMessage("Router: "+routerid+" can accept the LCD request.");
		}else if(status==2) {
			obj.setMessage("Router: "+routerid+" cache is full, can't accept LCD request.");
		}else if(status==3) {
			obj.setMessage("Device: "+ed.getId()+" not connect to this Router");
		}else if(status==4) {
			obj.setMessage("The LCD request already exist, doesn't need to send again.");
		}else if(status==5) {
			obj.setMessage("Request Fail. maybe server is sending command to router or router sending command to device.");
		}else if(status==6) {
			obj.setMessage("Fail. the device doesn't have LCD.");
		}
	}
	
	public static void analogySendLCDCommand(RespObj obj) {
		String hex = obj.getPacketData();
		String routerid = hex.substring(0,8);
		obj.setRouterId(routerid);
		EndDevice ed = new EndDevice();
		ed.setId(hex.substring(8,16));
		ed.setLcdIndex(Integer.valueOf(hex.substring(16,18),16));
		if(obj.getPacketType().equals("09")) {
			ed.setAddress(Integer.valueOf(hex.substring(18,22),16));
			obj.setMessage("LCD Command Sending...");
		}else if(obj.getPacketType().equals("83")) {
			obj.setMessage("Device: "+ed.getId()+",Update LCD Success.");
		}else if(obj.getPacketType().equals("C2")) {
			obj.setMessage("Device: "+ed.getId()+",Update LCD Fail(Timeout).");
		}
		obj.setDeviceTmp(ed);
	}
	
}
