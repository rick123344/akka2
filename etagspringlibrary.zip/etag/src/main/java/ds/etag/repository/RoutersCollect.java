package ds.etag.repository;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ds.etag.listener.etagListener;
import ds.etag.model.EndDevice;
import ds.etag.model.RespObj;
import ds.etag.model.Router;
import ds.etag.thread.RouterListenerThread;
import ds.etag.util.ActionType;

public class RoutersCollect implements etagListener{
	public static Logger logger = LoggerFactory.getLogger(RoutersCollect.class);
	
	private static Map<String,EndDevice> currentDevices = new HashMap<String,EndDevice>();
	private static Map<String,Router> routerList = new HashMap<String,Router>();
	
	public RoutersCollect(){
		RouterListenerThread.addEtagListener(this);
	}
	
	@Override
	public void etagResponse(RespObj obj) {
//		System.out.println(obj);
//		logger.info(obj.toString());
		try {
			if(obj.getPacketType().equals("C1")){
				Router r = (Router)ActionType.analogyRouterInfo(obj);
				if(!routerList.containsKey(r.getId())){
					routerList.put(r.getId(), r);
					r.routerTimerReStart();
				}else{
					routerList.get(r.getId()).routerTimerReStart();
				}
				ActionType.sendToGetDevicesByRouter(r);
			}else if(obj.getPacketType().equals("15")) {
				Map<String,EndDevice> tmp = obj.getEndDevices();
				if(tmp.size()>0) {
					currentDevices.putAll(tmp);
				}else {
					routerList.get(obj.getRouterId()).setDevices(new HashMap<String,EndDevice>(currentDevices));
					clearDevices();
				}
			}else if(obj.getPacketType().equals("81")) {
				routerList.get(obj.getRouterId()).getDevices().putAll(obj.getEndDevices());
			}else if(obj.getPacketType().equals("82")) {
				routerList.get(obj.getRouterId()).getDevices().putAll(obj.getEndDevices());
			}
		}catch(Exception e) {
//			e.printStackTrace();
			logger.info("device not online");
		}
		
	}
	
	public static void reloadAllDevices(){
		for (Map.Entry<String, Router> r : routerList.entrySet()){
			Router tmp = new Router();
			tmp.setId(r.getValue().getId());
			tmp.setIp(r.getValue().getIp());
			tmp.setPort(r.getValue().getPort());
			try{
				ActionType.sendToGetDevicesByRouter(tmp);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
	
	public static void clearRouters() {
		routerList.clear();
	}
	
	public static void clearRouterById(String routerId){
		routerList.remove(routerId);
	}
	
	public static Map<String, Router> getRouters() {
		return routerList;
	} 
	
	public static void clearDevices() {
		currentDevices.clear();
	}
	
	public static Router getRouterByDeviceId(String id) {
		Router tr = null;
		for (Map.Entry<String, Router> r : routerList.entrySet()){
//		    System.out.println(r.getKey() + "/" + r.getValue());
		    if(r.getValue().getDevices().containsKey(id)) {
		    	tr = r.getValue();
		    	break;
		    }
		}
		return tr;
	}
	
	public static EndDevice getDeviceByDeviceId(String id){
		EndDevice ed = null;
		ed = getRouterByDeviceId(id).getDevices().get(id);
		return ed;
	}
	
	public static void setBusyByRouterId(String id,boolean busy){
		try{
			routerList.get(id).setBusy(busy);
		}catch(Exception e){
			
		}
	}
	
	
}
