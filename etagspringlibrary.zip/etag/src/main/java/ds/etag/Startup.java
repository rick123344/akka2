package ds.etag;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ds.etag.listener.etagListener;
import ds.etag.model.RespObj;
import ds.etag.thread.KeyboardListenerThread;
import ds.etag.repository.RoutersCollect;
import ds.etag.thread.RouterListenerThread;
public class Startup{
	private static Logger logger = LoggerFactory.getLogger(Startup.class);
	public Startup(){
//		logger.info("inStart");
//		RouterListenerThread.etagThreadStart();
//		KeyboardListenerThread klt = new KeyboardListenerThread();
//		klt.start();
	}
}