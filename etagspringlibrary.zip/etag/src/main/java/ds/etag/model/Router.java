package ds.etag.model;

import java.io.Serializable;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import ds.etag.listener.timeoutListener;
import ds.etag.repository.RoutersCollect;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class Router implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String id;
	private String ip;
	private int port;
	private int sleepTime;
	private int sendInfoTime;
	private Map<String,EndDevice> devices = new HashMap<>();
	private boolean busy=false;
	
	@Setter(AccessLevel.NONE)
	@Getter(AccessLevel.NONE)
	//exclude serializable
	private transient Timer timer = null;
	private int timeout = 3000;
	@Setter(AccessLevel.NONE)
	@Getter(AccessLevel.NONE)
	private transient Timer routerTimer = null;
	private int routerTimeout = 20000;
	
	private transient timeoutListener deviceTimeoutAction = null;
	private transient timeoutListener routerTimeoutAction = null;
	
	public void routerTimerReStart(){
		try{
			routerTimer.cancel();
			routerTimer.purge();
			routerTimer = null;
		}catch(Exception e){
			
		}
		routerTimer = new Timer(true);
		routerTimer.schedule(new TimerTask(){
			private Router rt;
			@Override
			public void run(){
				if(rt.getRouterTimeoutAction()==null){
					RoutersCollect.logger.info("Router: "+rt.getId()+" no response. clear this router data.");
				}else{
					rt.getRouterTimeoutAction().timeoutAction();
				}
				RoutersCollect.clearRouterById(rt.getId());
			}
			private TimerTask init(Router rt){
				this.rt = rt;
				return this;
			}
		}.init(this), this.routerTimeout);
	}
	
	public void setBusy(boolean busy){
		this.busy = busy;
		if(this.busy){
			startTimeout();
		}else{
			stopTimeout();
		}
	}
	private void startTimeout(){
		stopTimeout();
		timer = new Timer(true);
		timer.schedule(new TimerTask() {
			private Router rt;
			@Override
			public void run() {
				
				if(rt.isBusy()){
					if(rt.getDeviceTimeoutAction()==null){
						System.out.println(rt.getId()+" busy timeout . reset busy.");
					}else{
						rt.getDeviceTimeoutAction().timeoutAction();
					}
					rt.setBusy(false);
				}
			}
			private TimerTask init(Router rt) {
				this.rt = rt;
				return this;
			}
		}.init(this),this.timeout);
	}
	
	private void stopTimeout(){
		try{
			if(timer!=null){
				timer.cancel();
				timer.purge();
				timer = null;
			}
		}catch(Exception e){
			
		}
	}
	
	@Override
	public boolean equals(Object obj) {
		boolean isequal = false;
		if (obj != null && obj instanceof Router)
	    {
			isequal = (this.id .equals(((Router) obj).id) );
	    }
		return isequal;
	}
	
	@Override
	public int hashCode() {
		return 0;
	}
	
	public boolean isContains(List<Router> arr) {
		boolean isContain = false;
		for(Object obj:arr) {
			if(this.equals(obj)) {
				isContain = true;
				break;
			}
		}
		return isContain;
	}
	public boolean isContains(Map<String, Router> arr) {
		boolean isContain = false;
		if(arr.containsKey(this.id)) {
			isContain = true;
		}
		return isContain;
	}
	public void addDevice(EndDevice ed) {
		if(!devices.containsKey(ed.getId())) {
			devices.put(ed.getId(), ed);
		}
	}
	public void clearDevice() {
		devices.clear();
	}

}
