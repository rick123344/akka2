package ds.etag.model;

import java.io.Serializable;

import lombok.Data;

@Data 
public class Light implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	// status => 0 is low status, 1 is high status, 2 is bright status
	// highTime => working when status is 2, the high status time
	// lowTime => working when status is 2, the low status time
	private int status = 0;
	private int highTime = 0;
	private int lowTime = 0;
	
	public Light() {
		status = 0;
		highTime = 0;
		lowTime = 0;
	}
	
	public Light(Light light){
		this.status = light.getStatus();
		this.highTime = light.getHighTime();
		this.lowTime = light.getLowTime();
	}
	
	public Light(int s,int h, int l) {
		status = s;
		highTime = h;
		lowTime = l;
	}
	
	public Light(int s) {
		status = s;
	}
	
}