package ds.etag.model;

import java.io.Serializable;
import java.net.InetAddress;
import java.util.Map;

import lombok.Data;

@Data
public class RespObj implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	//source base info
	private String baseType = "nuknow";
	private String respBegin = "EB";
	private String respEnd = "EA";
	private String packetType;
	private String CSCheck;
	private String packetData;
	
	//response base info
	private String ip;
	private int port;
	private byte[] source;
	
	//different type have each data
	private String routerId;
	private int routerReportTime;
	private Router routers;
	
	private int endDeviceCount;
	private Map<String,EndDevice> endDevices;// 14 bytes
	
	private EndDevice deviceTmp;
	private int status;
	
	//error info
	private boolean pass = true;
	private String message;
}
