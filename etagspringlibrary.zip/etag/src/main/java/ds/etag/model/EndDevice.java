package ds.etag.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

import lombok.Data;

@Data
public class EndDevice implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String id;
	private String routeId;
	private int sleepTime;
	private int lcdIndex=1;
	private int battery;
	private String ledState;
	private int lastTime;
	private int timeout=0;
	private String[] data;
	private int address = 0;
	private int connectTime;
	private String ledType;
	
	private Light yellow = new Light();
	private Light green = new Light();
	private Light blue = new Light();
	private Light white = new Light();
	private Light red = new Light();
	
	// 0 not wait for response, send all command in a row
	// 1 wait for response, send next command after router response
	private int updateImageType = 1;
	
	public EndDevice(){
		
	}
	
	public EndDevice(EndDevice ed){
		this.id = ed.getId();
		this.routeId = ed.getRouteId();
		this.sleepTime = ed.getSleepTime();
		this.lcdIndex = ed.getLcdIndex();
		this.battery = ed.getBattery();
		this.ledState = ed.getLedState();
		this.lastTime = ed.getLastTime();
		this.timeout = ed.getTimeout();
		this.data = ed.getData();
		this.address = ed.getAddress();
		this.connectTime = ed.getConnectTime();
		this.ledType = ed.getLedType();
		this.yellow = new Light(ed.getYellow());
		this.green = new Light(ed.getGreen());
		this.blue = new Light(ed.getBlue());
		this.white = new Light(ed.getWhite());
		this.red = new Light(ed.getRed());
	}
	
	public void resetAddr(){
		this.address = 0;
	}
	
	public void addrNext(){
		this.address += 64;
	}
	
	public void setLcdIndex(int index){
		this.lcdIndex=index;
		checkLcdIndex();
	}
	public void setLcdIndex(){
		this.lcdIndex=generateRandom(this.lcdIndex);
		checkLcdIndex();
	}
	private void checkLcdIndex(){
		if(this.lcdIndex>=255){
			this.lcdIndex = 1;
		}
		if(this.lcdIndex<=0){
			this.lcdIndex = 1;
		}
	}
	private int generateRandom(int exclude) {
	    Random rand = new Random();
	    int range = 100 - 1 + 1;

	    int random = rand.nextInt(range) + 1;
	    if(exclude == random){
	    	random+=1;
	    }
	    return random;
	}
	
	@Override
	public boolean equals(Object obj) {
		boolean isequal = false;
		if (obj != null && obj instanceof EndDevice)
	    {
			isequal = (this.id .equals(((EndDevice) obj).id) );
	    }
		return isequal;
	}
	
	@Override
	public int hashCode() {
		return 0;
	}
	
	public boolean isContains(ArrayList<EndDevice> arr) {
		boolean isContain = false;
		for(Object obj:arr) {
			if(this.equals(obj)) {
				isContain = true;
				break;
			}
		}
		return isContain;
	}
	
}

