package ds.etag;

import javax.servlet.FilterConfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import ds.etag.thread.RouterListenerThread;;

@SpringBootApplication
public class Application{
	private static final Logger log = LoggerFactory.getLogger(Application.class);
	protected static FilterConfig filterConfig; 
//	@Autowired
//	static AutowireCapableBeanFactory beanFactory;
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
        RouterListenerThread.etagThreadStart();
//        WebApplicationContext wac = WebApplicationContextUtils.getWebApplicationContext(filterConfig.getServletContext());
//        AutowireCapableBeanFactory autowireCapableBeanFactory = wac.getAutowireCapableBeanFactory(); 
//        WriteEtagThread.writeEtagThreadStart();
//        autowireCapableBeanFactory.autowireBean(WriteEtagThread.wet);
//        WriteEtagThread.writeEtagThreadStart();
//        beanFactory.autowireBean(WriteEtagThread.wet);
    }
}


/**********************************************************

Default freemarker file path => src/main/resources/templates/
	using in controller :
	public String home(Model model){
		model.addAttribute("name","some value");
		return "index"; => get the .ftl in src/main/resources/templates/index.ftl
	}

Default static file path => src/main/public/
	using in *.ftl file:
	It's wrong to put public in href or src (/public/css/...)	
	<link href="/css/bootstrap.min.css" rel="stylesheet"/>
	<script src="/js/jquery.min.js"></script>

Default application.properties path => src/main/resources/application.properties

***********************************************************/