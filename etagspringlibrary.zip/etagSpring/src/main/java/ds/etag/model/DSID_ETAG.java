package ds.etag.model;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;


import lombok.Data;

@Entity
@Data
public class DSID_ETAG {
	@Id
	private String id;
	private String pic;
	private String status;
	@Column(name="UP_DATE")
	private Date upDate;
	@Column(name="IS_ONLINE")
	private String isOnline;
	@Column(name="INSERT_DATE")
	private Date insertDate;
}

