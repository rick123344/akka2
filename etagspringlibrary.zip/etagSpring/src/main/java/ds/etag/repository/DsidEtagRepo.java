package ds.etag.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import ds.etag.model.DSID_ETAG;

@Transactional
@Service
public interface DsidEtagRepo extends JpaRepository<DSID_ETAG, String>{
	DSID_ETAG findByid(String id);
	
	@Query(value="SELECT * FROM (SELECT * FROM DSID_ETAG d ORDER BY d.INSERT_DATE ASC) WHERE ROWNUM=1 ", nativeQuery=true)
	DSID_ETAG findTop1ByOrderByInsertDateASC();
	
	@Query(value="SELECT * FROM DSID_ETAG d ORDER BY d.INSERT_DATE ASC ", nativeQuery=true)
	List<DSID_ETAG> findAll();
	
	@Modifying(clearAutomatically = true)
	@Query("UPDATE DSID_ETAG d SET d.status=:status where d.id = :id")
    void updateStatusById(@Param("status") String status,@Param("id") String id);
	
	@Modifying(clearAutomatically = true)
	@Query("UPDATE DSID_ETAG d SET d.isOnline=:isOnline where d.id = :id")
    void updateIsOnlineById(@Param("isOnline") String isOnline,@Param("id") String id);
	
	@Modifying(clearAutomatically = true)
	@Query("UPDATE DSID_ETAG d SET d.upDate=:upDate where d.id = :id")
    void updateUpDateById(@Param("upDate") Date upDate,@Param("id") String id);
	
	@Modifying(clearAutomatically = true)
	@Query("UPDATE DSID_ETAG d SET d.pic=:pic where d.id = :id")
    void updatePicById(@Param("pic") String pic,@Param("id") String id);
	
}
