package ds.etag.controller;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import ds.etag.listener.etagListener;
import ds.etag.listener.timeoutListener;
import ds.etag.model.DSID_ETAG;
import ds.etag.model.EndDevice;
import ds.etag.model.RespObj;
import ds.etag.model.Router;
import ds.etag.repository.DsidEtagRepo;
import ds.etag.repository.RoutersCollect;
import ds.etag.thread.RouterListenerThread;
import ds.etag.util.ActionType;
import ds.etag.util.Common;

@Controller
public class WriteEtagThread extends Thread implements etagListener{
	private static final Logger log = LoggerFactory.getLogger(WriteEtagThread.class);
	public static WriteEtagThread wet = new WriteEtagThread();
	private static String deviceFlag = "";
	private static boolean running = true;
	private static boolean isInit = false;
	@Autowired
	private DsidEtagRepo DEP;
	@Autowired
    private SimpMessagingTemplate template;
	public void run() {
		RouterListenerThread.addEtagListener(this);
		writeStart();
	}
	public static void writeEtagThreadStart() {
		running = true;
		isInit = true;
		if(getWet()==null){
			setWet();
		}
		if(!getWet().isAlive()) {
			getWet().start();
		}
	}
	
	public static WriteEtagThread getWet(){
		return wet;
	}
	
	public static void setWet(){
		wet = new WriteEtagThread();
	}
	
	public static boolean isInit() {
		return isInit;
	}
	public static void writeEtagThreadStop() {
		running = false;
	}
	public static boolean isRunning() {
		return running;
	}
	long totalTime =0;
	long startTime = 0;
	private void writeStart() {
		while(true) {
			if(isRunning()) {
				try {
					startTime = System.nanoTime();
					WriteEtagThread.sleep(500);
					DSID_ETAG d= DEP.findTop1ByOrderByInsertDateASC();
					if(d!=null){
						setFlag(d.getId());
						messageOut(deviceFlag);
						Router r = RoutersCollect.getRouterByDeviceId(d.getId());
						if(r==null) {	//offline
							DEP.updateIsOnlineById("N", d.getId());
							log.info("not online "+ TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-startTime));
							RoutersCollect.reloadAllDevices();
						}else { //online
							//set device timeout 
							r.setTimeout(3600);
							//set timeout method
							r.setDeviceTimeoutAction(new timeoutListener(){
								@Override
								public void timeoutAction() {
									messageOutReload("timeout... update fail");
									RoutersCollect.reloadAllDevices();
								}
							});
							
							if(!r.isBusy()){
								if(totalTime!=0){
									log.info("totalTime: "+TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-totalTime));
								}
								totalTime = System.nanoTime();
								DEP.updateIsOnlineById("Y", d.getId());
								log.info("checkOnline : Y, "+ TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-startTime));
								if(d.getStatus()==null||d.getStatus().equals("N")) {
									EndDevice ed = r.getDevices().get(d.getId());
									ed.setTimeout(3000);
									
									long cit = System.nanoTime();
									if(d.getPic()==null||d.getPic().equals("")) {
										ed.setData(Common.imageToStringArray(Common.createEmptyImage()));
									}else {
										ed.setData(Common.getCreateImageByText(d.getPic()));
									}
									log.info("createImage "+ TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-cit));
									
									long scm = System.nanoTime();
									if(!r.isBusy()) {
										System.out.println(ed.getId()+", Send...");
										if(d.getPic()==null||d.getPic().equals("")) {
											ed.setLcdIndex(101);
											ActionType.sendToUpdateImage(ed, r, false);
										}else {
											ActionType.sendToUpdateImage(ed, r);
										}
									}
									log.info("sendCommand "+ TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-scm));
								}
							}
						}
					}
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public static String getFlag() {
		return deviceFlag;
	}
	public static void setFlag(String flag){
		deviceFlag = flag;
	}
	
	@Override
	public void etagResponse(RespObj obj) {
		switch(obj.getBaseType()){
			case "LEDSuccess":
				resetRouterBusy(obj);
				break;
			case "SleepTimeSuccess":
				resetRouterBusy(obj);
				break;
			case "SleepTimeFail":
				resetRouterBusy(obj);
				break;
			case "LCDSuccess":
				try{
					messageOutReload(obj.getDeviceTmp().getId()+" update success");
					DEP.delete(obj.getDeviceTmp().getId());
				}catch(Exception e1){
					log.error(e1.toString());
				}
				resetRouterBusy(obj);
				break;
			case "LEDFail":
				resetRouterBusy(obj);
				break;
			case "AskImageUpdate":
				resetRouterBusy(obj);
				break;
			case "LCDFail":
				DEP.updateStatusById("N", obj.getDeviceTmp().getId());
				messageOutReload(obj.getDeviceTmp().getId()+" update fail");
				resetRouterBusy(obj);
				break;
			default:
				resetRouterBusy(obj);
				break;
		}
		
	}
	public void resetRouterBusy(RespObj obj){
		RoutersCollect.setBusyByRouterId(obj.getRouterId(), false);
	}
	public void setRouterBusy(EndDevice ed){
		RoutersCollect.setBusyByRouterId(ed.getRouteId(), true);
	}
    public void messageOut(String message) {
    	template.convertAndSend("/epage",message);
    }
    
    public void messageOutReload(String message) {
    	template.convertAndSend("/relaodDevice",message);
    }
    
}
