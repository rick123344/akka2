package ds.etag.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;

import ds.etag.model.DSID_ETAG;
import ds.etag.model.EndDevice;
import ds.etag.model.Router;
import ds.etag.repository.DsidEtagRepo;
import ds.etag.repository.RoutersCollect;
import ds.etag.util.ActionType;
import ds.etag.util.Common;

@Controller
public class HomeController {
	
	//inject dependency to writeEtagThread
	@Autowired
	AutowireCapableBeanFactory beanFactory;
	
	@Autowired
	DsidEtagRepo DEP;
	
//    @RequestMapping("/home")
//	public String homes(@RequestParam(value="name", required=false, defaultValue="World") String name, Model model,HttpServletRequest req) {
//    	
////    	List<DSID_ETAG> eds = (List<DSID_ETAG>) DEP.findAll();
////    	for(DSID_ETAG e : eds) {
////    		System.out.println(e);
////    	}
//    	
//		model.addAttribute("name", name);
//		req.setAttribute("test","Request");
//		
////		File file = new File(path);
////		model.addAttribute("files",file.listFiles());
//		
//		return "index";// it's will archieve to src/main/resources/templates/index.ftl	
//    }
//    
    
    @RequestMapping("/Etag")
	public String Etag(Model model,HttpServletRequest req) {
    	
    	if(!WriteEtagThread.isInit()) {
    		WriteEtagThread.writeEtagThreadStart();
        	beanFactory.autowireBean(WriteEtagThread.wet);
    	}
    	
    	if(WriteEtagThread.isRunning()) {
    		model.addAttribute("threadStatus", "true");
    	}else {
    		model.addAttribute("threadStatus", "false");
    	}
    	model.addAttribute("devices",getAllDevices());
    	model.addAttribute("flag", WriteEtagThread.getFlag());
    	return "etag";
    }
    
    @RequestMapping("/Online")
    public String Online(Model model,HttpServletRequest req){
    	
    	model.addAttribute("devices",getOnlinesWithJson());
    	
    	return "online";
    }
    
    @ResponseBody
    @RequestMapping(value="/getOnlinesWithJson",produces="application/json")
    public String getOnlinesWithJson(){
    	JSONObject obj = new JSONObject(RoutersCollect.getRouters());
    	return obj.toString();
    }
    
    @ResponseBody
    @RequestMapping(value="/clear",produces="application/json")
    public String clear(HttpServletRequest request,@RequestParam("id") String id){
    	System.out.println(id);
//    	System.out.println(request.getParameter("id"));
    	JSONObject obj = new JSONObject();
    	try{
    		obj.put("status", "fail");
        	Router rt = RoutersCollect.getRouterByDeviceId(id);
        	EndDevice ed = rt.getDevices().get(id);
        	ed.setData(Common.imageToStringArray(Common.createEmptyImage()));
        	ed.setLcdIndex(101);
        	ActionType.sendToUpdateImage(ed, rt,false);
    		obj.put("status", "commandSendAlready");
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return obj.toString();
    }
    
    @ResponseBody
    @RequestMapping(value="/clearAll",produces="application/json")
    public String clearAll(HttpServletRequest request){
    	JSONObject obj = new JSONObject();
    	try{
    		obj.put("status", "fail");
    		for(Entry<String,Router> r: RoutersCollect.getRouters().entrySet()) {
    			Router rt = r.getValue();
    			for(Entry<String,EndDevice> e:rt.getDevices().entrySet()) {
    				EndDevice ed = e.getValue();
    				DSID_ETAG ND = new DSID_ETAG();
    				ND.setId(ed.getId());
    				ND.setPic("");
    				ND.setInsertDate(new Date());
    				ND.setIsOnline("Y");
    				ND.setStatus("N");
    				try {DEP.save(ND);}catch(Exception ee) {}
    			}
    		}
    		obj.put("status", "commandSendAlready");
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return obj.toString();
    }
    
	@ResponseBody
	@RequestMapping(value = "/test",produces = "application/json")
	public String tests(@RequestParam("value") String v){
		JSONObject result = new JSONObject();
		System.out.println("In: "+v+" ,"+Common.intToBinaryString(Integer.parseInt(v), 8));
		try {
			result.put("v",v);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result.toString();
	}
	
	@ResponseBody
	@RequestMapping("/processImage")
    public String processImage(@RequestParam("processImage") String img) {
		JSONObject result = new JSONObject();
		try {
			result.put("img", Common.imageToBase64(Common.base64ToImage(img)));
			System.out.println(img);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
    	return result.toString();
    }
	
	@ResponseBody
	@RequestMapping("/upload")
    public String upload(@RequestParam("imgurl") String imgurl) {
		JSONObject result = new JSONObject();
		try {
			result.put("status", "success");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
    	return result.toString();
    }
	
	@ResponseBody
	@RequestMapping("/updateDevice")
    public String updateDevice(@RequestParam("id") String id,@RequestParam("tar") String tar,@RequestParam("value") String value) {
		JSONObject result = new JSONObject();
		try {
			if(tar.equals("status")) {
				DEP.updateStatusById(value, id);
			}else if(tar.equals("pic")) {
				DEP.updatePicById(value,id);
			}
			result.put("status", "success");
		}catch(Exception e) {
			e.printStackTrace();
			try {
				result.put("status", "fail");
			}catch(Exception e1) {
				
			}
		}
    	return result.toString();
    }
	
	@ResponseBody
	@RequestMapping("/getAllDevices")
	public String getAllDevices() {
		List<DSID_ETAG> eds = (List<DSID_ETAG>)DEP.findAll();
//		JSONObject json = new JSONObject(); 
		JSONArray json = new JSONArray();
		ObjectMapper mapper = new ObjectMapper();
		try {
			for(DSID_ETAG d: eds) {
//				json.put(d.getId(), new JSONObject());
				Router r = RoutersCollect.getRouterByDeviceId(d.getId());
				
				if(r!=null) {
					d.setIsOnline("Y");
					
					String jsonInString = mapper.writeValueAsString(d);
					JSONObject o = new JSONObject(jsonInString);
					String jsonInString2 = mapper.writeValueAsString(r.getDevices().get(d.getId()));
					JSONObject o2 = new JSONObject(jsonInString2);
					JSONObject oo = new JSONObject();
					oo.put("EndDevice", o2);
					oo.put("DSID_ETAG", o);
					json.put(oo);
//					((JSONObject)json.get(d.getId())).put("EndDevice", o2);
//					((JSONObject)json.get(d.getId())).put("DSID_ETAG", o);
				}else {
					d.setIsOnline("N");
					String jsonInString = mapper.writeValueAsString(d);
					JSONObject o = new JSONObject(jsonInString);
					JSONObject oo = new JSONObject();
					oo.put("DSID_ETAG", o);
					json.put(oo);
//					((JSONObject)json.get(d.getId())).put("EndDevice", "");
//					((JSONObject)json.get(d.getId())).put("DSID_ETAG", o);
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
			try {
				json.put("Fail"+e.toString());
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
		
		return json.toString();
	}
	
	private static final String[] devicesId = {"00000006","000002D6"};
	
	@ResponseBody
	@RequestMapping("/testData")
    public String testData() {
		JSONObject result = new JSONObject();
		try {
			DSID_ETAG ND = new DSID_ETAG();
			String id = "";
			for(String s:devicesId){
				if(DEP.findByid(s)==null){
					id = s;
					break;
				}
			}
			if(id.equals("")){
				return result.toString();
			}
			ND.setId(id);
			ND.setPic(randomPic());
			ND.setInsertDate(new Date());
			if(RoutersCollect.getRouterByDeviceId(id)!=null) {
				ND.setIsOnline("Y");
			}else {
				ND.setIsOnline("N");
			}
			ND.setStatus("N");
			try{
				DEP.delete(id);
			}catch(Exception ee){
				
			}
			try{
				DEP.save(ND);
			}catch(Exception e2){
				
			}
			result.put("status", "success");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
    	return result.toString();
    }
	
	public String randomPic(){
		String str = "形體W PEGASUS + "+getRandom(50)+" ESS SU17 ID";
		str += ","+getRandom(250);
		str += ",部位:前面片/鞋身/鞋舌上層/鞋舌中層";
		str += ",4EV, 54H ,01V,00A,65N,46E,78A,00A,"+getRandom(25)+",6.5,"+getRandom(8)+",7.5,8,8.5,"+getRandom(8)+",9.5,"+getRandom(8)+","+getRandom(8)+","+getRandom(8)+","+getRandom(8)+","+getRandom(8)+","+getRandom(8)+","+getRandom(8)+","+getRandom(8)+"";
		return str;
	}
	public int getRandom(int range){
		Random rand = new Random();
		int random = rand.nextInt(range) + 1;
		return random;
	}
	@MessageMapping("/stopThread")
    @SendTo("/othermessage")
    public String stopThread(String message) {
		WriteEtagThread.writeEtagThreadStop();
		if(WriteEtagThread.isRunning()) {
			return "true";
		}else {
			return "false";
		}
    }
	
	@MessageMapping("/startThread")
    @SendTo("/othermessage")
    public String startThread(String message) {
		WriteEtagThread.writeEtagThreadStart();
		if(WriteEtagThread.isRunning()) {
			return "true";
		}else {
			return "false";
		}
    }
	
}

