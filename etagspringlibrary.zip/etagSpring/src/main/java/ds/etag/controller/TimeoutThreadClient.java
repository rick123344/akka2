package ds.etag.controller;

import ds.etag.thread.TimeoutThread;

import java.util.Timer;
import java.util.TimerTask;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ds.etag.repository.RoutersCollect;

public class TimeoutThreadClient extends TimeoutThread{
	private static Logger logger = LoggerFactory.getLogger(TimeoutThreadClient.class);
	
	public TimeoutThreadClient(String name, long timer) {
		super(name, timer);
		
	}
	
	@Override
	public void countDown(long timer) {
		System.out.println(this.name+" CountDown ");
		t = new Timer(true);
		t.schedule(new TimerTask() {
			private String name;
			@Override
			public void run() {
				if(this.name.equals("WriteEtag")) {
//					WriteEtagThread.setIsWait(false);
//					logger.info(this.name+"Update Timeout... Reset Flag");
//					RoutersCollect.reloadAllDevices();
				}
			}
			private TimerTask init(String name) {
				this.name = name;
				return this;
			}
		}.init(name),timer);
	}
	
	
}
